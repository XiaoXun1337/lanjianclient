package dev.tenacity.hackerdetector;

public enum Category {

    COMBAT("Combat"),
    MOVEMENT("Movement"),
    PLAYER("Player"),
    MISC("Misc"),
    EXPLOIT("Exploit");

    Category(String name) {
    }

}
