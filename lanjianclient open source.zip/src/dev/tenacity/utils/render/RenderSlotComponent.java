package dev.tenacity.utils.render;

import dev.tenacity.event.ListenerAdapter;
import lombok.Getter;
import net.minecraft.item.ItemStack;

import static dev.tenacity.utils.Utils.mc;

public class RenderSlotComponent extends ListenerAdapter {

    private static int spoofedSlot;

    @Getter
    private static boolean spoofing;

    public void startSpoofing(int slot) {
        spoofing = true;
        spoofedSlot = slot;
    }

    public void stopSpoofing() {
        spoofing = false;
    }

    public static int getSpoofedSlot() {
        return spoofing ? spoofedSlot : mc.thePlayer.inventory.currentItem;
    }

    public static ItemStack getSpoofedStack() {
        return spoofing ? mc.thePlayer.inventory.getStackInSlot(spoofedSlot) : mc.thePlayer.inventory.getCurrentItem();
    }
}
