package dev.tenacity.utils;

public interface EnvironmentConstants {

    String BASE = "https://intent.store/api/",
            API_VERSION = "1.0",
            USER_AGENT = "Intent-API/" + API_VERSION + " Dominic";

}
