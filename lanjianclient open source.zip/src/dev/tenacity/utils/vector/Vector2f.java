package dev.tenacity.utils.vector;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@AllArgsConstructor
public final class Vector2f {
    public float x, y;
}
