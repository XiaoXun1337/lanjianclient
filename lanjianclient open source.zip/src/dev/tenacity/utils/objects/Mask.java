package dev.tenacity.utils.objects;

import dev.tenacity.utils.render.ShaderUtil;

public class Mask {

    private final ShaderUtil maskShader = new ShaderUtil("Tenacity/Shaders/mask.frag");

}
