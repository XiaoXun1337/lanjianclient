package dev.tenacity.utils;


import dev.tenacity.event.Cancellable;
import dev.tenacity.event.Event;

public abstract class EventCancellable extends Event
        implements
        Cancellable {
    private boolean cancelled;

    protected EventCancellable() {
    }

    @Override
    public boolean isCancelled() {
        return this.cancelled;
    }

    @Override
    public void setCancelled(boolean state) {
        this.cancelled = state;
    }


}

