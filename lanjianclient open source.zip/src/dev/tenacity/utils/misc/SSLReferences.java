package dev.tenacity.utils.misc;

public class SSLReferences {

    public static final String STOREPASS = "ZnFBV2c3eHAyNjdXRjNMa1JrUUwzTkRIZGhzdA==";
    public static final String KEYPASS = "ZFVSZTM2UGFVY1VlU2E2Yko5ODRlaUZEOHp1NmJyTnNTbVo3a0pKOEtyTWY4QjlhVXdIckVyNQ==";

}
