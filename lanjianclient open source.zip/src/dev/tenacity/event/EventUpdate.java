package dev.tenacity.event;




public class EventUpdate extends Event {
}
