package dev.tenacity.event;


import net.minecraft.client.multiplayer.WorldClient;

public class EventWorldLoad extends Event {

    private final WorldClient world;

    public EventWorldLoad(WorldClient world) {
        this.world = world;
    }

    public WorldClient getWorld() {
        return world;
    }
}
