package dev.tenacity.event;




public class EventTick extends Event {
}
