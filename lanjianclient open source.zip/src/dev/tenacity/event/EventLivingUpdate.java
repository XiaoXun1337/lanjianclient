package dev.tenacity.event;




public class EventLivingUpdate extends Event {
}
