package dev.tenacity.event;

public interface EventListener {
    void onEvent(Event event);
}
