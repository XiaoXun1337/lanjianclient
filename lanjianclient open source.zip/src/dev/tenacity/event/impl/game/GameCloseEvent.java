package dev.tenacity.event.impl.game;

import dev.tenacity.event.Event;

public class GameCloseEvent extends Event {
}
