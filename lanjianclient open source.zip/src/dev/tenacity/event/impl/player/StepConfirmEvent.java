package dev.tenacity.event.impl.player;

import dev.tenacity.event.Event;

public class StepConfirmEvent extends Event {
}
