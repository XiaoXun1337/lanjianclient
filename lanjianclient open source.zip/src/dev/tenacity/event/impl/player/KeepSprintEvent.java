package dev.tenacity.event.impl.player;

import dev.tenacity.event.Event;

public class KeepSprintEvent extends Event {

    public KeepSprintEvent() {
    }
}
