package dev.tenacity.event.impl.player;

import dev.tenacity.event.Event;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class JumpEvent extends Event {
    private float yaw;
    private float jumpMotion;
}

