package dev.tenacity.event.impl.player;

import dev.tenacity.event.Event;
import dev.tenacity.event.EventMotion;

public class UpdateEvent extends Event {
    public EventMotion.EventState eventState;
    public boolean isPost() {
        return this.eventState == EventMotion.EventState.POST;
    }
}
