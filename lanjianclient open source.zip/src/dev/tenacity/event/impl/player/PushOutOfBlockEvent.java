package dev.tenacity.event.impl.player;

import dev.tenacity.event.Event;

public class PushOutOfBlockEvent extends Event {
}
