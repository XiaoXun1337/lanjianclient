package dev.tenacity.event.impl.render;

import dev.tenacity.event.Event;

public class PreRenderEvent extends Event {
}
