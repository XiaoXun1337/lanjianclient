package dev.tenacity.ui.mainmenu.particles;

/**
 * @author cedo
 * @since 05/23/2022
 */
public enum ParticleType {
    BIG,
    SMALL
}
