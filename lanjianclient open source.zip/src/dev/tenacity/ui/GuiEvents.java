package dev.tenacity.ui;

public enum GuiEvents {

    DRAW,
    CLICK,
    RELEASE

}
