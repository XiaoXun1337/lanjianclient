package dev.tenacity.module.impl.movement;

import dev.tenacity.event.impl.player.BlockPlaceableEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.event.impl.player.SafeWalkEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.render.HUDMod;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.ui.notifications.NotificationManager;
import dev.tenacity.ui.notifications.NotificationType;
import dev.tenacity.utils.MovementFix;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.component.RotationComponent;
import dev.tenacity.utils.component.SlotComponent;
import dev.tenacity.utils.misc.EnumFacingUtils;
import dev.tenacity.utils.misc.SlotUtil;
import dev.tenacity.utils.player.*;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.render.RoundedUtil;
import dev.tenacity.utils.render.RenderSlotComponent;
import dev.tenacity.utils.server.PacketUtils;
import dev.tenacity.utils.vector.Vector2f;
import dev.tenacity.utils.vector.Vector3d;
import net.minecraft.block.Block;
import net.minecraft.block.BlockAir;
import net.minecraft.block.BlockSnow;
import net.minecraft.client.gui.IFontRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.util.*;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.concurrent.ThreadLocalRandom;

import static dev.tenacity.utils.misc.MathUtils.getRandom;

public class Scaffold extends Module {
    private final ModeSetting countMode = new ModeSetting("Block Counter", "tenacity", "None", "tenacity", "Basic", "Polar");
    private final ModeSetting swingMode = new ModeSetting("How Swing", "Animation", "Animation", "Packet");
    private final ModeSetting blockPicker = new ModeSetting("Block Picker", "Switch", "None", "Switch", "Spoof");
    private final BooleanSetting move = new BooleanSetting("Strafe Fix", true);
    public final BooleanSetting safeWalk = new BooleanSetting("Safe Walk", false);
    private final BooleanSetting keepY = new BooleanSetting("Keep Y", false);
    public final BooleanSetting keepFov = new BooleanSetting("Keep Fov", false);
    public final NumberSetting fovValue = new NumberSetting("Fov", 1.0, 2.0, 1.0, 0.1);
    private final NumberSetting tellyTicks = new NumberSetting("Telly Ticks", 2, 10, 0, 1);
    private final NumberSetting upTicks = new NumberSetting("UP Ticks", 2, 10, 0, 1);
    private EnumFacingUtils enumFacingABC;
    private BlockPos blockFace;
    private static float targetYaw;
    private Vec3 targetBlock;
    private float targetPitch;
    private int ticksOnAir;
    private int prevSlot;
    private final int oldSlot;
    double startY;
    private final Animation anim = new DecelerateAnimation(250, 1);

    public Scaffold() {
        super("Scaffold", Category.MOVEMENT, "Rise Moment");
        this.oldSlot = 0;
        fovValue.addParent(keepFov, a -> keepFov.isEnabled());
        addSettings(countMode, swingMode, blockPicker, keepY, move, safeWalk, keepFov, fovValue, tellyTicks, upTicks);
    }


    @Override
    public void onEnable() {
        if (mc.thePlayer == null) {
            return;
        }

        targetYaw = mc.thePlayer.rotationYaw - 180;
        targetPitch = 90;
        runMode();
        prevSlot = mc.thePlayer.inventory.currentItem;
        super.onEnable();
    }

    @Override
    public void onDisable() {
        mc.gameSettings.keyBindJump.pressed = GameSettings.isKeyDown(mc.gameSettings.keyBindJump);
        switchToOriginalSlot();
        super.onDisable();
    }

    public void runMode() {
        if (!keepY.isEnabled()) {
            if (mc.thePlayer.onGround && MoveUtil.isMoving()) {
                mc.thePlayer.jump();
            }
        }
    }

    private void switchToOriginalSlot() {
        if(!blockPicker.is("None")) {
            mc.thePlayer.inventory.currentItem = oldSlot;
        }
        RenderSlotComponent renderSlotComponent = new RenderSlotComponent();
        renderSlotComponent.stopSpoofing();
    }

    @Override
    public void onMotionEvent(MotionEvent e) {
        //挥手动画
        switch (swingMode.getMode()) {
            case "Animation":
                if (MovementUtils.isMoving()) {
                    mc.thePlayer.swingItem();
                }
                break;
            case "Packet":
                break;
        }

        if (e.isPre()) {
            //Used to detect when to place a block, if over air, allow placement of blocks
            if (PlayerUtil.blockRelativeToPlayer(0, -1, 0) instanceof BlockAir) {
                ticksOnAir++;
            } else {
                ticksOnAir = 0;
            }
            // Gets block to place
            targetBlock = PlayerUtil.getPlacePossibility(0, 0, 0);
            if (targetBlock == null) {
                return;
            }
            //Gets EnumFacing
            enumFacingABC = PlayerUtil.getEnumFacing(targetBlock);
            if (enumFacingABC == null) {
                return;
            }
            final BlockPos position = new BlockPos(targetBlock.xCoord, targetBlock.yCoord, targetBlock.zCoord);
            blockFace = position.add(enumFacingABC.getOffset().xCoord, enumFacingABC.getOffset().yCoord, enumFacingABC.getOffset().zCoord);
            if (blockFace == null || enumFacingABC == null) {
                return;
            }
            calculateRotations();
            if (!GameSettings.isKeyDown(mc.gameSettings.keyBindJump)) {
                mc.gameSettings.keyBindJump.pressed = ((mc.thePlayer.onGround && MoveUtil.isMoving()) || mc.gameSettings.keyBindJump.isPressed());
            } else {
                mc.gameSettings.keyBindJump.pressed = GameSettings.isKeyDown(mc.gameSettings.keyBindJump);
            }
        }
        if (e.isPost()) {
            int slot = SlotUtil.findBlock();
            if (slot == -1) {
                NotificationManager.post(NotificationType.WARNING, "Scaffold", "No blocks in hotbar!");
                toggle();
                return;
            }
            if (blockPicker.is("Spoof")) {
                RenderSlotComponent renderSlotComponent = new RenderSlotComponent();
                renderSlotComponent.startSpoofing(oldSlot);
            }
            if (!blockPicker.is("None")) {
                for (int i = 8; i >= 0; i--) {
                    ItemStack stack = mc.thePlayer.inventory.getStackInSlot(i);

                    if (stack != null && stack.getItem() instanceof ItemBlock && !PlayerUtil.isBlockBlacklisted(stack.getItem()) && stack.stackSize > 0) {
                        mc.thePlayer.inventory.currentItem = i;
                        break;
                    }
                }
            }
            if (slot != prevSlot && blockPicker.is("Switch")) {
                mc.thePlayer.inventory.currentItem = slot;
            }
        }
    }

    @Override
    public void onBlockPlaceable(BlockPlaceableEvent event) {
        if (mc.thePlayer == null) {
            return;
        }
        // Same Y
        if (keepY.isEnabled()) {
            final boolean sameY = !GameSettings.isKeyDown(mc.gameSettings.keyBindJump) && MoveUtil.isMoving();

            if (startY - 1 != Math.floor(targetBlock.yCoord) && !mc.thePlayer.onGround && sameY) {
                return;
            }
        }
        if (ticksOnAir > getRandom(0, 0) && RayCastUtil.overBlock(RotationComponent.lastServerRotations, enumFacingABC.getEnumFacing(), blockFace, false)) {

            Vec3 hitVec = this.getHitVec();

            if (mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, SlotComponent.getItemStack(), blockFace, enumFacingABC.getEnumFacing(), hitVec)) {
                PacketUtils.sendPacket(new C0APacketAnimation());
            }
            mc.rightClickDelayTimer = 0;
        }
        //For Same Y
        if (mc.thePlayer != null && keepY.isEnabled()) {
            if (mc.thePlayer.onGround || (mc.gameSettings.keyBindJump.isKeyDown() && !MoveUtil.isMoving())) {
                startY = Math.floor(mc.thePlayer.posY);
            }
            if (mc.thePlayer.posY < startY) {
                startY = mc.thePlayer.posY;
            }
        }
    }


    public void getRotationsA() {
        final Vector2f rotations = RotationUtil.calculate(new Vector3d(blockFace.getX(), blockFace.getY(), blockFace.getZ()), enumFacingABC.getEnumFacing());
        targetYaw = rotations.x;
        if (mc.gameSettings.keyBindJump.isKeyDown() && !MoveUtil.isMoving()) {
            targetYaw = rotations.x;
        }
        targetPitch = rotations.y;
    }

    private float getYaw() {
        final Vector2f rotations = RotationUtil.calculate(new Vector3d(blockFace.getX(), blockFace.getY(), blockFace.getZ()), enumFacingABC.getEnumFacing());
        if (mc.thePlayer.hurtTime > 0 || mc.gameSettings.keyBindBack.isKeyDown()) {
            return mc.thePlayer.rotationYaw - rotations.x;
        }
        return mc.thePlayer.rotationYaw;
    }

    public void calculateRotations() {
        final Vector2f rotations = RotationUtil.calculate(new Vector3d(blockFace.getX(), blockFace.getY(), blockFace.getZ()), enumFacingABC.getEnumFacing());
        if (mc.thePlayer.offGroundTicks > (GameSettings.isKeyDown(mc.gameSettings.keyBindJump) ? upTicks.getValue() : tellyTicks.getValue())) {
            if (!RayCastUtil.overBlock(RotationComponent.rotations, enumFacingABC.getEnumFacing(), blockFace, true)) {
                getRotationsA();
                targetYaw = rotations.x;
            }
        } else {
            getRotationsA();
            targetYaw = getYaw();
        }
        RotationComponent.setRotations(new Vector2f(targetYaw, targetPitch), 10f, move.isEnabled() ? MovementFix.NORMAL : MovementFix.OFF);
    }

    public static Vec3i translate(BlockPos blockPos, EnumFacing enumFacing) {
        double x = blockPos.getX();
        double y = blockPos.getY();
        double z = blockPos.getZ();
        double r1 = ThreadLocalRandom.current().nextDouble(0.3, 0.5);
        double r2 = ThreadLocalRandom.current().nextDouble(0.9, 1.0);
        if (enumFacing.equals(EnumFacing.UP)) {
            x += r1;
            z += r1;
            y += 1.0;
        } else if (enumFacing.equals(EnumFacing.DOWN)) {
            x += r1;
            z += r1;
        } else if (enumFacing.equals(EnumFacing.WEST)) {
            y += r2;
            z += r1;
        } else if (enumFacing.equals(EnumFacing.EAST)) {
            y += r2;
            z += r1;
            x += 1.0;
        } else if (enumFacing.equals(EnumFacing.SOUTH)) {
            y += r2;
            x += r1;
            z += 1.0;
        } else if (enumFacing.equals(EnumFacing.NORTH)) {
            y += r2;
            x += r1;
        }
        return new Vec3i(x, y, z);
    }

    public Vec3 getHitVec() {
        /* Correct HitVec */
        Vec3 hitVec = new Vec3(blockFace.getX() + Math.random(), blockFace.getY() + Math.random(), blockFace.getZ() + Math.random());
        final MovingObjectPosition movingObjectPosition = RayCastUtil.rayCast(RotationComponent.rotations, mc.playerController.getBlockReachDistance());
        switch (enumFacingABC.getEnumFacing()) {
            case DOWN:
                hitVec.yCoord = blockFace.getY();
                break;
            case UP:
                hitVec.yCoord = blockFace.getY() + 1;
                break;
            case NORTH:
                hitVec.zCoord = blockFace.getZ();
                break;
            case EAST:
                hitVec.xCoord = blockFace.getX() + 1;
                break;
            case SOUTH:
                hitVec.zCoord = blockFace.getZ() + 1;
                break;
            case WEST:
                hitVec.xCoord = blockFace.getX();
                break;
        }
        if (movingObjectPosition != null && movingObjectPosition.getBlockPos().equals(blockFace) &&
                movingObjectPosition.sideHit == enumFacingABC.getEnumFacing()) {
            hitVec = movingObjectPosition.hitVec;
        }
        return hitVec;
    }

    public void renderCounterBlur() {
        if (!enabled && anim.isDone()) return;
        int slot = ScaffoldUtils.getBlockSlot();
        ItemStack heldItem = slot == -1 ? null : mc.thePlayer.inventory.mainInventory[slot];
        int count = slot == -1 ? 0 : ScaffoldUtils.getBlockCount();
        String countStr = String.valueOf(count);
        IFontRenderer fr = mc.fontRendererObj;
        ScaledResolution sr = new ScaledResolution(mc);
        int color;
        float x, y;
        String str = countStr + " block" + (count != 1 ? "s" : "");
        float output = anim.getOutput().floatValue();
        switch (countMode.getMode()) {
            case "tenacity":
                float blockWH = heldItem != null ? 15 : -2;
                int spacing = 3;
                String text = "§l" + countStr + "§r block" + (count != 1 ? "s" : "");
                float textWidth = tenacityFont18.getStringWidth(text);

                float totalWidth = ((textWidth + blockWH + spacing) + 6) * output;
                x = sr.getScaledWidth() / 2f - (totalWidth / 2f);
                y = sr.getScaledHeight() - (sr.getScaledHeight() / 2f - 20);
                float height = 20;
                RenderUtil.scissorStart(x - 1.5, y - 1.5, totalWidth + 3, height + 3);
                RoundedUtil.drawRound(x, y, totalWidth, height, 5, Color.BLACK);
                RenderUtil.scissorEnd();
                break;
            case "Basic":
                x = sr.getScaledWidth() / 2F - fr.getStringWidth(str) / 2F + 1;
                y = sr.getScaledHeight() / 2F + 10;
                RenderUtil.scaleStart(sr.getScaledWidth() / 2.0F, y + fr.FONT_HEIGHT / 2.0F, output);
                fr.drawStringWithShadow(str, x, y, 0x000000);
                RenderUtil.scaleEnd();
                break;
            case "Polar":
                x = sr.getScaledWidth() / 2F - fr.getStringWidth(countStr) / 2F + (heldItem != null ? 6 : 1);
                y = sr.getScaledHeight() / 2F + 10;

                GlStateManager.pushMatrix();
                RenderUtil.fixBlendIssues();
                GL11.glTranslatef(x + (heldItem == null ? 1 : 0), y, 1);
                GL11.glScaled(anim.getOutput().floatValue(), anim.getOutput().floatValue(), 1);
                GL11.glTranslatef(-x - (heldItem == null ? 1 : 0), -y, 1);

                fr.drawOutlinedString(countStr, x, y, ColorUtil.applyOpacity(0x000000, output), true);

                if (heldItem != null) {
                    double scale = 0.7;
                    GlStateManager.color(1, 1, 1, 1);
                    GlStateManager.scale(scale, scale, scale);
                    RenderHelper.enableGUIStandardItemLighting();
                    mc.getRenderItem().renderItemAndEffectIntoGUI(
                            heldItem,
                            (int) ((sr.getScaledWidth() / 2F - fr.getStringWidth(countStr) / 2F - 7) / scale),
                            (int) ((sr.getScaledHeight() / 2F + 8.5F) / scale)
                    );
                    RenderHelper.disableStandardItemLighting();
                }
                GlStateManager.popMatrix();
                break;
        }
    }

    public void renderCounter() {
        anim.setDirection(enabled ? Direction.FORWARDS : Direction.BACKWARDS);
        if (!enabled && anim.isDone()) return;
        int slot = ScaffoldUtils.getBlockSlot();
        ItemStack heldItem = slot == -1 ? null : mc.thePlayer.inventory.mainInventory[slot];
        int count = slot == -1 ? 0 : ScaffoldUtils.getBlockCount();
        String countStr = String.valueOf(count);
        IFontRenderer fr = mc.fontRendererObj;
        ScaledResolution sr = new ScaledResolution(mc);
        int color;
        float x, y;
        String str = countStr + " block" + (count != 1 ? "s" : "");
        float output = anim.getOutput().floatValue();
        switch (countMode.getMode()) {
            case "tenacity":
                float blockWH = heldItem != null ? 15 : -2;
                int spacing = 3;
                String text = "§l" + countStr + "§r block" + (count != 1 ? "s" : "");
                float textWidth = tenacityFont18.getStringWidth(text);

                float totalWidth = ((textWidth + blockWH + spacing) + 6) * output;
                x = sr.getScaledWidth() / 2f - (totalWidth / 2f);
                y = sr.getScaledHeight() - (sr.getScaledHeight() / 2f - 20);
                float height = 20;
                RenderUtil.scissorStart(x - 1.5, y - 1.5, totalWidth + 3, height + 3);
                RoundedUtil.drawRound(x, y, totalWidth, height, 5, ColorUtil.tripleColor(20, .45f));

                tenacityFont18.drawString(text, x + 3 + blockWH + spacing, y + tenacityFont18.getMiddleOfBox(height) + .5f, -1);

                if (heldItem != null) {
                    RenderHelper.enableGUIStandardItemLighting();
                    mc.getRenderItem().renderItemAndEffectIntoGUI(heldItem, (int) x + 3, (int) (y + 10 - (blockWH / 2)));
                    RenderHelper.disableStandardItemLighting();
                }
                RenderUtil.scissorEnd();
                break;
            case "Basic":
                x = sr.getScaledWidth() / 2F - fr.getStringWidth(str) / 2F + 1;
                y = sr.getScaledHeight() / 2F + 10;
                RenderUtil.scaleStart(sr.getScaledWidth() / 2.0F, y + fr.FONT_HEIGHT / 2.0F, output);
                fr.drawStringWithShadow(str, x, y, -1);
                RenderUtil.scaleEnd();
                break;
            case "Polar":
                color = count < 24 ? 0xFFFF5555 : count < 128 ? 0xFFFFFF55 : 0xFF55FF55;
                x = sr.getScaledWidth() / 2F - fr.getStringWidth(countStr) / 2F + (heldItem != null ? 6 : 1);
                y = sr.getScaledHeight() / 2F + 10;

                GlStateManager.pushMatrix();
                RenderUtil.fixBlendIssues();
                GL11.glTranslatef(x + (heldItem == null ? 1 : 0), y, 1);
                GL11.glScaled(anim.getOutput().floatValue(), anim.getOutput().floatValue(), 1);
                GL11.glTranslatef(-x - (heldItem == null ? 1 : 0), -y, 1);

                fr.drawOutlinedString(countStr, x, y, ColorUtil.applyOpacity(color, output), true);

                if (heldItem != null) {
                    double scale = 0.7;
                    GlStateManager.color(1, 1, 1, 1);
                    GlStateManager.scale(scale, scale, scale);
                    RenderHelper.enableGUIStandardItemLighting();
                    mc.getRenderItem().renderItemAndEffectIntoGUI(
                            heldItem,
                            (int) ((sr.getScaledWidth() / 2F - fr.getStringWidth(countStr) / 2F - 7) / scale),
                            (int) ((sr.getScaledHeight() / 2F + 8.5F) / scale)
                    );
                    RenderHelper.disableStandardItemLighting();
                }
                GlStateManager.popMatrix();
                break;
        }
    }

    public boolean isAirBlock(Block block) {
        return block.getMaterial().isReplaceable() && (!(block instanceof BlockSnow) || block.getBlockBoundsMaxY() <= 0.125D);
    }

    @Override
    public void onSafeWalkEvent(SafeWalkEvent event) {
        if (safeWalk.isEnabled() || ScaffoldUtils.getBlockCount() == 0) {
            event.setSafe(true);
        }
    }
}

