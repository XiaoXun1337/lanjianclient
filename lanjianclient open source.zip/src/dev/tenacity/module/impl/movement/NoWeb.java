package dev.tenacity.module.impl.movement;

import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.utils.player.BlockUtils;
import dev.tenacity.utils.server.PacketUtils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockWeb;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.util.BlockPos;

import java.util.Map;

public class NoWeb extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Grim", "Vanilla", "Grim");


    public NoWeb(){
        super("NoWeb", Category.MOVEMENT, "22666j");
        this.addSettings(mode);
    }
    @Override
    public void onDisable() {NoWeb.mc.timer.timerSpeed = 1.0f;
    }

    @Override
    public void onMotionEvent(MotionEvent event){
        if (!NoWeb.mc.thePlayer.isInWeb) {
            return;
        }
        switch (this.mode.getMode()){
            case "Vanilla":
                NoWeb.mc.thePlayer.isInWeb = false;
                break;
            case "Grim":
                Map<BlockPos, Block> searchBlock = BlockUtils.searchBlocks(2);
                for (Map.Entry<BlockPos, Block> block : searchBlock.entrySet()) {
                    if (!(NoWeb.mc.theWorld.getBlockState(block.getKey()).getBlock() instanceof BlockWeb)) continue;
                    PacketUtils.sendPacketNoEvent(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.ABORT_DESTROY_BLOCK, block.getKey(), NoWeb.mc.objectMouseOver.sideHit));
                    PacketUtils.sendPacketNoEvent(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.STOP_DESTROY_BLOCK, block.getKey(), NoWeb.mc.objectMouseOver.sideHit));
                }
                NoWeb.mc.thePlayer.isInWeb = false;
                break;
        }
    }
}