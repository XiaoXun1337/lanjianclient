package dev.tenacity.module.impl.movement;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.player.UpdateEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.combat.KillAura;
import dev.tenacity.module.impl.player.Timer;
import dev.tenacity.module.settings.Setting;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.component.RotationComponent;
import dev.tenacity.utils.player.MoveUtil;
import dev.tenacity.utils.player.MovementUtils;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.item.EntityBoat;
import net.minecraft.entity.item.EntityMinecart;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.potion.Potion;
import net.minecraft.util.AxisAlignedBB;

public final class Speed extends Module {
    private final ModeSetting mode = new ModeSetting("Mode", "Grim", "Grim","Hypixel","Entity","Legit");
    private final NumberSetting range = new NumberSetting("CheckRange", 1, 2, 0.1,0.1);

    private final NumberSetting boostAmount = new NumberSetting("BoostAmount", 4, 8, 0,1);
    int groundTicks = 0;
    boolean jumping;
    public Speed() {
        super("Speed", Category.MOVEMENT, "Makes you go faster");
        Setting.addParent(mode, m -> m.is("Entity"),boostAmount,range);
        this.addSettings(mode,boostAmount,range);
        setSuffix(mode.getMode());
    }


    @Override
    public void onUpdateEvent(UpdateEvent event) {

        switch (mode.getMode()) {
            case "Legit" :
                //十分的斯玛特

                if (MoveUtil.isMoving() && !mc.thePlayer.isInWater() && !mc.thePlayer.isInLava()) {
                    jumping = true;
                    mc.gameSettings.keyBindJump.pressed = true;
                }


                if (!MoveUtil.isMoving() && jumping) {
                    mc.gameSettings.keyBindJump.pressed = false;
                    jumping = false;
                }

                break;
            case "Entity":
                if (isNull() || Tenacity.INSTANCE.moduleCollection.getModule(Timer.class).isEnabled())
                    return;
                if (mc.thePlayer.moveForward == 0.0f && mc.thePlayer.moveStrafing == 0.0f) {
                    return;
                }
                int  collisions = 0;
                for (Entity entity : mc.thePlayer.getEntityWorld().loadedEntityList) {
                    if (canCauseSpeed(entity) && (mc.thePlayer.getEntityBoundingBox().expand(range.getValue(),range.getValue(),range.getValue()).intersectsWith(entity.getEntityBoundingBox()))) {
                        collisions += 1;
                    }
                }
                double yaw2 = Math.toRadians(MoveYaw());
                double boost = boostAmount.getValue().floatValue() * 0.01 * collisions;
                mc.thePlayer.addVelocity(-Math.sin(yaw2) * boost, 0.0, Math.cos(yaw2) * boost);
                break;

            case "Grim":
                AxisAlignedBB playerBox = Speed.mc.thePlayer.boundingBox.expand(1.0, 1.0, 1.0);
                int c = 0;
                for (Entity entity : Speed.mc.theWorld.loadedEntityList) {
                    if (!(entity instanceof EntityLivingBase) && !(entity instanceof EntityBoat) && !(entity instanceof EntityMinecart) && !(entity instanceof EntityFishHook) || entity instanceof EntityArmorStand || entity.getEntityId() == Speed.mc.thePlayer.getEntityId() || !playerBox.intersectsWith(entity.boundingBox) || entity.getEntityId() == -8 || entity.getEntityId() == -1337)
                        continue;
                    ++c;
                }
                if (c > 0 && MoveUtil.isMoving()) {
                    double strafeOffset = (double) Math.min(c, 3) * 0.04;
                    float yaw = this.getMoveYaw();
                    double mx = -Math.sin(Math.toRadians(yaw));
                    double mz = Math.cos(Math.toRadians(yaw));
                    Speed.mc.thePlayer.addVelocity(mx * strafeOffset, 0.0, mz * strafeOffset);
                    if (c < 4 && KillAura.target != null && this.shouldFollow()) {
                        Speed.mc.gameSettings.keyBindLeft.pressed = true;
                        break;
                    }
                    Speed.mc.gameSettings.keyBindLeft.pressed = GameSettings.isKeyDown(Speed.mc.gameSettings.keyBindLeft);
                    break;
                }
                Speed.mc.gameSettings.keyBindLeft.pressed = GameSettings.isKeyDown(Speed.mc.gameSettings.keyBindLeft);
                break;
            case "Hypixel":
                if (MovementUtils.isMoving()) {
                    if (Math.abs(mc.thePlayer.movementInput.moveStrafe) < 0.1F) {
                        mc.thePlayer.jumpMovementFactor = 0.026499F;
                    } else {
                        mc.thePlayer.jumpMovementFactor = 0.0244F;
                    }

                    mc.gameSettings.keyBindJump.pressed = GameSettings.isKeyDown(mc.gameSettings.keyBindJump);
                    if (MovementUtils.getSpeed() < 0.195F && !mc.thePlayer.onGround) {
                        MovementUtils.strafe(0.195F);
                    }

                    if (mc.thePlayer.onGround) {
                        mc.gameSettings.keyBindJump.pressed = false;
                        mc.thePlayer.jump();
                        if (mc.thePlayer.isAirBorne) {
                            MovementUtils.strafe();
                            if (MovementUtils.getSpeed() < (mc.thePlayer.isPotionActive(Potion.moveSpeed) ? 0.55F : 0.5F)) {
                                MovementUtils.strafe(mc.thePlayer.isPotionActive(Potion.moveSpeed) ? 0.5349F : 0.4849F);
                            }
                        }
                    }
                }
        }
    }

    public boolean shouldFollow() {
        return isEnabled() && Speed.mc.gameSettings.keyBindJump.isKeyDown();
    }

    private float getMoveYaw() {
        EntityPlayerSP thePlayer = Speed.mc.thePlayer;
        float moveYaw = thePlayer.rotationYaw;
        if (thePlayer.moveForward != 0.0f && thePlayer.moveStrafing == 0.0f) {
            moveYaw += thePlayer.moveForward > 0.0f ? 0.0f : 180.0f;
        } else if (thePlayer.moveForward != 0.0f) {
            moveYaw = thePlayer.moveForward > 0.0f ? moveYaw + (thePlayer.moveStrafing > 0.0f ? -45.0f : 45.0f) : moveYaw - (thePlayer.moveStrafing > 0.0f ? -45.0f : 45.0f);
            moveYaw += thePlayer.moveForward > 0.0f ? 0.0f : 180.0f;
        } else if (thePlayer.moveStrafing != 0.0f) {
            moveYaw += thePlayer.moveStrafing > 0.0f ? -70.0f : 70.0f;
        }
        if (KillAura.target != null && Speed.mc.gameSettings.keyBindJump.isKeyDown()) {
            moveYaw = RotationComponent.rotations.getX();
        }
        return moveYaw;
    }
    public  static  double MoveYaw(){
        return  (MovementUtils.getDirection() * 180f / Math.PI);
    }
    private boolean canCauseSpeed(Entity entity) {
        return entity != mc.thePlayer && entity instanceof EntityPlayer;
    }
    public void onDisable() {
        if (jumping) {
            mc.gameSettings.keyBindJump.pressed = false;
            jumping = false;
        }
        this.groundTicks = 0;
        mc.timer.timerSpeed = 1.0F;
        super.onDisable();
    }
}