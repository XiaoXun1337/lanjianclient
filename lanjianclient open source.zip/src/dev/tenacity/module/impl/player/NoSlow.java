
package dev.tenacity.module.impl.player;

import com.viaversion.viaversion.api.Via;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Type;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.Protocol1_8TO1_9;
import de.gerrygames.viarewind.utils.PacketUtil;
import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.event.impl.player.SlowDownEvent;
import dev.tenacity.event.impl.player.UpdateEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.utils.player.MoveUtil;
import dev.tenacity.utils.server.PacketUtils;
import io.netty.buffer.Unpooled;
import net.minecraft.client.Minecraft;
import net.minecraft.item.*;
import net.minecraft.network.PacketBuffer;
import net.minecraft.network.play.client.*;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;

public class NoSlow extends Module {
    private final ModeSetting mode = new ModeSetting("Mode", "Grim", "Grim", "Watchdog", "Intave", "Polar");
    private final BooleanSetting food = new BooleanSetting("Food", true);
    private final BooleanSetting bow = new BooleanSetting("Bow", true);
    private final BooleanSetting potions = new BooleanSetting("Potions", true);

    public static  boolean hasDroppedFood = false;
    public static boolean fix = false;
    private boolean postPlace;
    private boolean lastUsingRestItem = false;

    public NoSlow() {
        super("NoSlow", Category.PLAYER, "prevent item slowdown");
        food.addParent(mode, modeSetting -> modeSetting.is("Grim"));
        bow.addParent(mode, modeSetting -> modeSetting.is("Grim"));
        this.addSettings(mode, food, bow,potions);
    }

    @Override
    public void onDisable() {
        lastUsingRestItem = false;
        super.onDisable();
    }

    public static boolean hasSwordwithout() {
        return  Minecraft.getMinecraft().thePlayer.getHeldItem().getItem() instanceof ItemSword;
    }


    public void onSlowDownEvent(SlowDownEvent event) {
        if (mc.thePlayer == null || mc.theWorld == null || mc.thePlayer.getHeldItem() == null) return;
        if (this.potions.isEnabled() && NoSlow.mc.thePlayer.isUsingItem() && NoSlow.mc.thePlayer.getHeldItem().getItem() instanceof ItemPotion) {
            event.cancel();
        }
        switch (mode.getMode()) {
            case "Grim":
                if (mc.thePlayer.getHeldItem().getItem() instanceof ItemFood && food.isEnabled()) return;
                if (mc.thePlayer.getHeldItem() != null && (mc.thePlayer.getHeldItem().getItem() instanceof ItemSword
                        || (mc.thePlayer.getHeldItem().getItem() instanceof ItemBow && bow.isEnabled())) && mc.thePlayer.isUsingItem())
                    event.setCancelled(true);
                if (!mc.thePlayer.isSprinting() && !mc.thePlayer.isSneaking() && MoveUtil.isMoving()) {
                    mc.thePlayer.setSprinting(true);
                }
                break;
            case "Watchdog":
                if (NoSlow.mc.thePlayer.isUsingItem()) {
                    if (NoSlow.mc.thePlayer.getCurrentEquippedItem().getItem() instanceof ItemFood && this.food.isEnabled()) {
                        PacketUtils.sendPacket(new C08PacketPlayerBlockPlacement(new BlockPos(-1, -1, -1), 0, null, 0.0f, 0.0f, 0.0f));
                    }
                    if (NoSlow.mc.thePlayer.getCurrentEquippedItem().getItem() instanceof ItemPotion && this.potions.isEnabled()) {
                        PacketUtils.sendPacket(new C08PacketPlayerBlockPlacement(new BlockPos(-1, -1, -1), 0, null, 0.0f, 0.0f, 0.0f));
                        NoSlow.mc.thePlayer.motionX *= (double)0.8f;
                        NoSlow.mc.thePlayer.motionZ *= (double)0.8f;
                    }
                }
                if (NoSlow.mc.thePlayer.isUsingItem()) break;
                if (NoSlow.mc.thePlayer.isSprinting() || !NoSlow.mc.thePlayer.onGround || !(NoSlow.mc.thePlayer.moveForward > 0.0f)) break;
                NoSlow.mc.thePlayer.setSprinting(true);
                break;
            case "Intave":
            case "Polar":
                if (!(mc.thePlayer.getHeldItem().getItem() instanceof net.minecraft.item.ItemBow))
                    event.setCancelled(true);
                if (!mc.thePlayer.isSprinting() && !mc.thePlayer.isSneaking() && MoveUtil.isMoving()) {
                    mc.thePlayer.setSprinting(true);
                }
                break;
        }
    }

    @Override
    public void onUpdateEvent(UpdateEvent event) {
        if (mc.thePlayer.isUsingItem() && mode.is("Watchdog")) {
            if (mc.thePlayer.ticksExisted % 3 == 0) {
                mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(new BlockPos(-1, -1, -1), 1, null, 0, 0, 0));
            }
        }
    }

    public void onMotionEvent(MotionEvent e) {
        setSuffix(mode.getMode());

        switch (this.mode.getMode()) {
            case "Watchdog":
                if (e.isPost()) {
                    if (postPlace) {
                        if (mc.thePlayer.ticksExisted % 3 == 0) {
                            mc.thePlayer.sendQueue.addToSendQueue(new C08PacketPlayerBlockPlacement(mc.thePlayer.getHeldItem()));
                        }
                        postPlace = false;
                    }
                }
                break;
            case "Grim":
                if  (!mc.isSingleplayer()) {
                    if (e.isPre()) {
                        if (mc.thePlayer == null || mc.theWorld == null || mc.thePlayer.getHeldItem() == null) return;
                        ItemStack itemInHand = mc.thePlayer.getCurrentEquippedItem();
                        ItemStack itemStack = mc.thePlayer.getHeldItem();
                        int itemID = Item.getIdFromItem(itemInHand.getItem());
                        int itemMeta = itemInHand.getMetadata();
                        String itemId = itemInHand.getItem().getUnlocalizedName();
                        if(mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemFood && food.isEnabled()) {
                            if (mc.thePlayer.getHeldItem() != null && (!((itemID == 322 && itemMeta == 1) || itemId.equals("item.appleGoldEnchanted")))) {
                                if (Minecraft.getMinecraft().thePlayer.inventory.getCurrentItem() != null) {

                                    if (Minecraft.getMinecraft().thePlayer.getCurrentEquippedItem().getItem() instanceof ItemBlock) {
                                        Minecraft.getMinecraft().rightClickDelayTimer = 4;
                                    } else {
                                        Minecraft.getMinecraft().rightClickDelayTimer = 4;
                                    }
                                }
                                if (mc.thePlayer.isUsingItem() && !hasDroppedFood  && itemStack.stackSize > 1) {
                                    mc.getNetHandler().addToSendQueue(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.DROP_ITEM, new BlockPos(0, 0, 0), EnumFacing.DOWN));
                                    hasDroppedFood = true;
                                    fix =true;
                                } else if (!mc.thePlayer.isUsingItem()) {
                                    hasDroppedFood = false;
                                    new Thread(() -> {try {Thread.sleep(500); fix =false;} catch (InterruptedException ex) {ex.printStackTrace();}}).start();

                                }
                            }
                        } else {
                            fix = false;
                        }
                        if (Minecraft.getMinecraft().thePlayer.inventory.getCurrentItem() != null) {
                            if ((mc.thePlayer.isBlocking()) ||mc.thePlayer.isUsingItem() && hasSwordwithout()) {
                                mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange((mc.thePlayer.inventory.currentItem + 1) % 9));
                                mc.getNetHandler().addToSendQueue(new C17PacketCustomPayload(Tenacity.NAME, new PacketBuffer(Unpooled.buffer())));
                                mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));
                            }
                            if (mc.thePlayer.getHeldItem().getItem() instanceof ItemBow && mc.thePlayer.isUsingItem() && bow.isEnabled() && !mc.thePlayer.isSneaking()) {
                                mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange((mc.thePlayer.inventory.currentItem + 1) % 9));
                                mc.getNetHandler().addToSendQueue(new C17PacketCustomPayload(Tenacity.NAME, new PacketBuffer(Unpooled.buffer())));
                                mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));
                            }
                        }
                    }
                    if (e.isPost()) {
                        if (mc.thePlayer.getHeldItem() == null) return;
                        if (mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemSword && mc.thePlayer.isUsingItem()) {
                            PacketWrapper useItem = PacketWrapper.create(29, null, Via.getManager().getConnectionManager().getConnections().iterator().next());
                            useItem.write(Type.VAR_INT, 1);
                            PacketUtil.sendToServer(useItem, Protocol1_8TO1_9.class, true, true);
                            PacketWrapper useItem2 = PacketWrapper.create(29, null, Via.getManager().getConnectionManager().getConnections().iterator().next());
                            useItem2.write(Type.VAR_INT, 0);
                            PacketUtil.sendToServer(useItem2, Protocol1_8TO1_9.class, true, true);
                        }
                        if (mc.thePlayer.getHeldItem().getItem() instanceof ItemBow && mc.thePlayer.isUsingItem() && bow.isEnabled()) {
                            PacketWrapper useItem = PacketWrapper.create(29, null, Via.getManager().getConnectionManager().getConnections().iterator().next());
                            useItem.write(Type.VAR_INT, 1);
                            PacketUtil.sendToServer(useItem, Protocol1_8TO1_9.class, true, true);
                            PacketWrapper useItem2 = PacketWrapper.create(29, null, Via.getManager().getConnectionManager().getConnections().iterator().next());
                            useItem2.write(Type.VAR_INT, 0);
                            PacketUtil.sendToServer(useItem2, Protocol1_8TO1_9.class, true, true);
                        }
                    }
                }
                break;
            case "Intave":
                final Item item = mc.thePlayer != null ? mc.thePlayer.getHeldItem().getItem() : null;
                if (!e.isPre()) return;
                if (!mc.thePlayer.isUsingItem()) {
                    lastUsingRestItem = false;
                    return;
                }

                if (!MoveUtil.isMoving()) return;
                if (isRest(item)) {
                    if (!lastUsingRestItem) {
                        PacketUtils.sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.UP));
                    }
                    lastUsingRestItem = true;
                } else {
                    lastUsingRestItem = false;

                    if (item instanceof ItemSword) {
                        PacketUtils.sendPacket(new C08PacketPlayerBlockPlacement(mc.thePlayer.getHeldItem()));
                    }
                }
                break;
            case "Polar":
                final Item item2 = mc.thePlayer != null ? mc.thePlayer.getHeldItem().getItem() : null;
                if (!e.isPre()) return;
                if (!mc.thePlayer.isUsingItem()) {
                    lastUsingRestItem = false;
                    return;
                }

                if (isRest(item2)) {
                    if (!lastUsingRestItem) {
                        PacketUtils.sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.UP));
                    }
                    PacketUtils.sendPacket(new C0CPacketInput(0, 0.82f, false, false));
                    lastUsingRestItem = true;
                } else {
                    lastUsingRestItem = false;

                    if (item2 instanceof ItemSword) {
                        PacketUtils.sendPacket(new C08PacketPlayerBlockPlacement(mc.thePlayer.getHeldItem()));
                        PacketUtils.sendPacket(new C0CPacketInput(0, 0.82f, false, false));
                    }
                }
                break;
        }
    }

    public static boolean isRest(Item item) {
        return item instanceof ItemFood || item instanceof ItemPotion;
    }
}
