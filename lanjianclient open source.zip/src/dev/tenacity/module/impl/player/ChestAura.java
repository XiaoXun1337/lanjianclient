package dev.tenacity.module.impl.player;


import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.game.WorldEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.combat.KillAura;
import dev.tenacity.module.impl.combat.ThrowerAura;
import dev.tenacity.module.impl.movement.Scaffold;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.MultipleBoolSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.MovementFix;
import dev.tenacity.utils.component.RotationComponent;
import dev.tenacity.utils.component.SlotComponent;
import dev.tenacity.utils.time.TimerUtil;
import net.minecraft.block.BlockBrewingStand;
import net.minecraft.block.BlockChest;
import net.minecraft.block.BlockFurnace;
import net.minecraft.client.gui.inventory.GuiContainer;
import net.minecraft.util.BlockPos;
import net.minecraft.util.MovingObjectPosition;

import java.util.ArrayList;
import java.util.List;



public class ChestAura extends Module {

    private final NumberSetting range = new NumberSetting("Range", 3.0, 5.0, 1.0, 0.1);
    private final MultipleBoolSetting type = new MultipleBoolSetting("Type",

            new BooleanSetting("Chest",true),
            new BooleanSetting("Furnace", true),
            new BooleanSetting("BrewingStand",true)

    );
    private final NumberSetting delay = new NumberSetting("Delay", 50, 5000, 0, 1);


    public BlockPos blockPos;

    public TimerUtil timer = new TimerUtil();

    public static List<BlockPos> list = new ArrayList<>();

    public ChestAura() {
        super("ChestAura", Category.PLAYER,"Fuckkkkk");
        addSettings(range,type,delay);
    }
   @Override
   public void onDisable(){
        list.clear();
        super.onDisable();
   }

    @Override
    public void onMotionEvent(MotionEvent e) {
        if(e.isPre()) blockPos = null;

        if (!timer.hasTimeElapsed(delay.getValue()) || NoSlow.hasDroppedFood || mc.thePlayer.isUsingItem() || mc.thePlayer.ticksExisted % 20 == 0  || KillAura.target != null || ThrowerAura.tick != 0 || ChestAura.mc.currentScreen instanceof GuiContainer || Tenacity.INSTANCE.getModuleCollection().getModule(Scaffold.class).isEnabled()) {
            return;
        }
        if(e.isPre()) {
            float radius;
            for (float y2 = radius = this.range.getValue().floatValue(); y2 >= -radius; y2 -= 1.0f) {
                for (float x2 = -radius; x2 <= radius; x2 += 1.0f) {
                    for (float z = -radius; z <= radius; z += 1.0f) {
                        BlockPos pos = new BlockPos(mc.thePlayer.posX +  x2,  mc.thePlayer.posY +  y2,  mc.thePlayer.posZ +  z);
                        if (blockPos == null && !list.contains(pos) && Math.sqrt(mc.thePlayer.getDistanceSq(pos)) <= range.getValue()) {
                            if ((mc.theWorld.getBlockState(pos).getBlock() instanceof BlockBrewingStand && type.getSetting("BrewingStand").isEnabled()) || (mc.theWorld.getBlockState(pos).getBlock() instanceof BlockChest && type.getSetting("Chest").isEnabled()) || (mc.theWorld.getBlockState(pos).getBlock() instanceof BlockFurnace && type.getSetting("Furnace").isEnabled())) {
                                blockPos = pos;
                            }
                        }
                    }
                }

                if (blockPos != null) {
                    float[] rotation = getRotationsToPosition(blockPos);
                    RotationComponent.setRotations(rotation, 10, MovementFix.NORMAL);
                }
            }
        }
      if(e.isPost()) {
          MovingObjectPosition obj = mc.thePlayer.rayTraceCustom(4.5, e.getYaw(),  e.getPitch());
          if (obj.getBlockPos().equals(blockPos) && obj.getBlockPos() != null) {
              if (mc.playerController.onPlayerRightClick(mc.thePlayer, mc.theWorld, SlotComponent.getItemStack(), obj.getBlockPos(), obj.sideHit, obj.hitVec)) {
                  list.add(blockPos);
                  timer.reset();
              }
          }
      }
            
    }



    @Override
    public void onWorldEvent(WorldEvent e) {
        list.clear();
    }


    public static float[] getRotationsToPosition(BlockPos pos) {
        double deltaX = pos.getX() - mc.thePlayer.posX + 0.5 - mc.thePlayer.motionX;
        double deltaY = pos.getY() - mc.thePlayer.getEntityBoundingBox().minY - mc.thePlayer.getEyeHeight() + 0.5;
        double deltaZ = pos.getZ()- mc.thePlayer.posZ + 0.5 - mc.thePlayer.motionZ;
        double horizontalDistance = Math.sqrt(deltaX * deltaX + deltaZ * deltaZ);
        float yaw = (float)Math.toDegrees(-Math.atan2(deltaX, deltaZ));
        float pitch = (float)Math.toDegrees(-Math.atan2(deltaY, horizontalDistance));
        return new float[]{yaw, pitch};
    }
}
