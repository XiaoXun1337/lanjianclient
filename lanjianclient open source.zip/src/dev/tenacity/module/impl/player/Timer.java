package dev.tenacity.module.impl.player;

import dev.tenacity.event.impl.network.PacketReceiveEvent;
import dev.tenacity.event.impl.network.PacketSendEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.event.impl.player.MoveEvent;
import dev.tenacity.event.impl.render.Render2DEvent;
import dev.tenacity.event.impl.render.ShaderEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.render.HUDMod;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.DecelerateAnimation;
import dev.tenacity.utils.player.MovementUtils;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.render.RoundedUtil;
import dev.tenacity.utils.server.PacketUtils;
import dev.tenacity.utils.time.TimerUtil;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0FPacketConfirmTransaction;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.network.play.server.S18PacketEntityTeleport;
import net.minecraft.util.ChatComponentText;

import java.awt.*;
import java.util.concurrent.ConcurrentLinkedQueue;

public final class Timer extends Module {
    private final NumberSetting amount = new NumberSetting("Amount", 1, 10, 0.1, 0.1);

    private final BooleanSetting balance = new BooleanSetting("Balance",false);


    private final BooleanSetting pointMessage = new BooleanSetting("pointMessage",false);
    private int count = 0;
    private TimerUtil timerUtil = new TimerUtil();

    final ConcurrentLinkedQueue<Packet<?>> packets = new ConcurrentLinkedQueue<>();

    @Override
    public void onMotionEvent(MotionEvent event) {
        if(!balance.isEnabled()) {
            mc.timer.timerSpeed = amount.getValue().floatValue();
        }else{
            PacketUtils.sendPacketNoEvent(new C0FPacketConfirmTransaction(0,(short) 0,true));
            if(count >= 0) {
                mc.timer.timerSpeed = MovementUtils.isMoving() ? amount.getValue().floatValue() : 1f;
            }else{
                toggle();
            }
        }
    }
    @Override
    public void onPacketReceiveEvent(PacketReceiveEvent event) {
        if(event.getPacket() instanceof S12PacketEntityVelocity && ((S12PacketEntityVelocity) event.getPacket()).entityID == mc.thePlayer.getEntityId()) toggle();
        if(event.getPacket() instanceof S18PacketEntityTeleport && ((S18PacketEntityTeleport) event.getPacket()).getEntityId() == mc.thePlayer.getEntityId())toggle();
        if(event.getPacket() instanceof S08PacketPlayerPosLook) toggle();

    }

    @Override
    public void onPacketSendEvent(PacketSendEvent event) {
        if(event.getPacket() instanceof C03PacketPlayer){
            if(!((C03PacketPlayer) event.getPacket()).isMoving()) {
                count += 50;
                event.cancel();
            }else{
                count -= 50;
            }
        }
        if(event.getPacket() instanceof C0FPacketConfirmTransaction){
            event.cancel();
            packets.add(event.getPacket());
        }
        if(event.getPacket() instanceof C02PacketUseEntity && ((C02PacketUseEntity) event.getPacket()).getAction() == C02PacketUseEntity.Action.ATTACK) toggle();
    }
    @Override
    public void onDisable() {
        if (!packets.isEmpty()) {
            packets.forEach(PacketUtils::sendPacketNoEvent);
            packets.clear();
        }
        count = 0;
        mc.timer.timerSpeed = 1;
        super.onDisable();
    }


    @Override
    public void onRender2DEvent(Render2DEvent event) {

        if (mc.thePlayer != null) {
            if (timerUtil.hasTimeElapsed(1000, true)) {
                if (pointMessage.isEnabled()) {
                    mc.ingameGUI.getChatGUI().printChatMessage(new ChatComponentText("Balance -> " + count));
                }
            }
        }
    }
    final Animation anim = new DecelerateAnimation(250, 1);
    public void renderCounterBlur() {
        if (!enabled && anim.isDone()) return;
        String countStr = String.valueOf(count);
        ScaledResolution sr = new ScaledResolution(mc);
        float x, y;
        float output = anim.getOutput().floatValue();
        int spacing = 3;
        String text = "§l" + countStr + "§r balance";
        float textWidth = tenacityFont18.getStringWidth(text);
        float totalWidth = ((textWidth  + spacing) + 6) * output;
        x = sr.getScaledWidth() / 2f - (totalWidth / 2f);
        y = sr.getScaledHeight() - (sr.getScaledHeight() / 2f - 20) + 40;
        float height = 40;
//        RenderUtil.scissorStart(x, y, totalWidth, height);
//        RoundedUtil.drawRound(x, y, totalWidth, height, 5, Interface.getClientColors().getFirst());
        RoundedUtil.drawGradientRound(x, y, totalWidth, height, 5,255);
//        RenderUtil.scissorEnd();
    }

    public void renderCounter() {
        anim.setDirection(enabled ? Direction.FORWARDS : Direction.BACKWARDS);
        if (!enabled && anim.isDone()) return;
        String countStr = String.valueOf(count);
        ScaledResolution sr = new ScaledResolution(mc);
        float x, y;
        float output = anim.getOutput().floatValue();
        int spacing = 3;
        String text = "§l" + countStr + "§r balance";
        float textWidth = tenacityFont18.getStringWidth(text);

        float totalWidth = ((textWidth + spacing) + 6) * output;
        x = sr.getScaledWidth() / 2f - (totalWidth / 2f);
        y = sr.getScaledHeight() - (sr.getScaledHeight() / 2f - 20) + 40;
        float height = 20;
        Color c1 = ColorUtil.applyOpacity(HUDMod.getClientColors().getFirst(), 222);
        Color c2 = ColorUtil.applyOpacity(HUDMod.getClientColors().getSecond(), 222);
        RenderUtil.scissorStart(x - 1.5, y - 1.5, totalWidth + 3, height + 23);
        RoundedUtil.drawRound(x, y, totalWidth, height + 20, 5, ColorUtil.tripleColor(20, .45f));
        tenacityFont18.drawString(text, x + 2  + spacing, y + tenacityFont18.getMiddleOfBox(height) + .5f , -1);
        RoundedUtil.drawGradientHorizontal(x,y + tenacityFont18.getMiddleOfBox(height) + .5f,1.5f,7.0f,1.5f,c1,c2);
        RenderUtil.scissorEnd();
        RoundedUtil.drawGradientHorizontal(x+3, y + tenacityFont18.getMiddleOfBox(height) + .5f + 15F,  (totalWidth - 8) * Math.min(Math.max((count/7500f),0F),1f) ,  5, 1.5f, c1, c2);
    }
    public Timer() {
        super("Timer", Category.PLAYER, "changes game speed");
        this.addSettings(amount,balance,pointMessage);
    }

}
