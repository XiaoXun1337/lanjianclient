package dev.tenacity.module.impl.player;

import dev.tenacity.event.impl.network.PacketReceiveEvent;
import dev.tenacity.event.impl.network.PacketSendEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.event.impl.player.MoveEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.utils.player.MovementUtils;
import dev.tenacity.utils.server.PacketUtils;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemBucket;
import net.minecraft.item.ItemEnderPearl;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;

import java.util.concurrent.ConcurrentLinkedQueue;

public class Stuck extends Module {

    private boolean stuck = false;

    private Boolean isInVoid() {
        int i;
        for (i = 0 ; i < 128 ; i ++) {
            if (MovementUtils.isOnGround(i)) {
                return false;
            }
        }
        return true;
    }
    @Override
    public void onMotionEvent(MotionEvent event){
        if(isInVoid()) stuck = true;
    }

    @Override
    public void onDisable() {
        stuck = false;
        super.onDisable();
    }
    @Override
    public void onPacketSendEvent(PacketSendEvent event){
        final ConcurrentLinkedQueue<Packet<?>> packets = new ConcurrentLinkedQueue<>();
        if(stuck) {
            if (event.getPacket() instanceof C03PacketPlayer) {
                event.cancel();
            }
            if (event.getPacket() instanceof C08PacketPlayerBlockPlacement && (mc.thePlayer.getHeldItem().getItem() instanceof ItemEnderPearl || mc.thePlayer.getHeldItem().getItem() instanceof ItemBucket || (mc.thePlayer.getHeldItem().getItem() instanceof ItemBlock && mc.gameSettings.keyBindUseItem.isKeyDown()))) {
                event.cancel();
                packets.add(event.getPacket());
                PacketUtils.sendPacketNoEvent(new C03PacketPlayer.C05PacketPlayerLook(mc.thePlayer.rotationYaw,mc.thePlayer.rotationPitch,mc.thePlayer.onGround));
                PacketUtils.sendPacketNoEvent(packets.poll());
                packets.clear();
            }
        }
    }
    @Override
    public void onMoveEvent(MoveEvent event){
        if(stuck) event.cancel();
    }
    @Override
    public void onPacketReceiveEvent(PacketReceiveEvent event){
        if(event.getPacket() instanceof S08PacketPlayerPosLook) toggle();
    }
    public Stuck() {
        super("Stuck", Category.PLAYER, "saves you from the void");
    }
}
