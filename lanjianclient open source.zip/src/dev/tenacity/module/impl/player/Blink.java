package dev.tenacity.module.impl.player;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;


import dev.tenacity.event.*;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.ui.notifications.NotificationManager;
import dev.tenacity.ui.notifications.NotificationType;
import dev.tenacity.utils.EventPacketReceive;
import dev.tenacity.utils.server.PacketUtils;
import lombok.var;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0APacketAnimation;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.network.play.server.S02PacketChat;

public class Blink extends Module {
    private final LinkedList<List<Packet<?>>> packets = new LinkedList();
    public EntityOtherPlayerMP fakePlayer;
    private int ticks;
    private final ModeSetting modeValue = new ModeSetting("Mode", "Delay","Delay","SlowRelease","Simple");
    public BooleanSetting skywars = new BooleanSetting("SkyWars",false);
    public BooleanSetting autoclose = new BooleanSetting("AutoClose", false);
    private int countdownTicks = -1;  // 用于计时
    public Blink() {
        super("Blink", Category.PLAYER,"AutoClip");
        addSettings(modeValue,skywars,autoclose);
    }


    @Override
    public void onEnable() {
        if (Blink.mc.thePlayer == null) {
            return;
        }
        countdownTicks = -1; // 重置计时器
        this.packets.clear();
        this.packets.add(new ArrayList());
        this.ticks = 0;
        this.fakePlayer = new EntityOtherPlayerMP(Blink.mc.theWorld, Blink.mc.thePlayer.getGameProfile());
        this.fakePlayer.clonePlayer(Blink.mc.thePlayer, true);
        this.fakePlayer.copyLocationAndAnglesFrom(Blink.mc.thePlayer);
        this.fakePlayer.rotationYawHead = Blink.mc.thePlayer.rotationYawHead;
        if (!skywars.getConfigValue()) {
            Blink.mc.theWorld.addEntityToWorld(-1337, this.fakePlayer);
        }
    }

    @EventTarget
    public void onWorld(EventWorldLoad event) {
        this.toggle();
    }

    @Override
    public void onDisable() {
        countdownTicks = -1; // 重置计时器
        this.packets.forEach(this::sendTick);
        this.packets.clear();
        try {
            if (this.fakePlayer != null) {
                Blink.mc.theWorld.removeEntity(this.fakePlayer);
            }
        }
        catch (Exception exception) {
        }
    }

    @EventTarget
    public void onPacket(EventHigherPacketSend event) {
        Packet packet = event.getPacket();
        if (PacketUtils.isCPacket(packet)) {
            mc.addScheduledTask(() -> this.packets.getLast().add(packet));
            event.setCancelled(true);
        }
    }
    @EventTarget
    public void onPacket(EventPacketReceive eventPacketReceive) {
        var packet = eventPacketReceive.getPacket();
        if(skywars.getConfigValue()) {
            if (packet instanceof S02PacketChat) {
                var chatComponent = ((S02PacketChat) packet).getChatComponent();
                if (chatComponent != null) {
                    var text = chatComponent.getUnformattedText();
                    if (text.contains("开始倒计时: 1 秒")) {
                        countdownTicks = 20;
                    }
                    if (text.contains("起床战争")) {
                        this.toggle();
                    }
                }
            }
        }
    }
    @EventTarget
    public void onTick(EventTick event) {
        ++this.ticks;
        this.packets.add(new ArrayList());
        switch (this.modeValue.getConfigValue()) {
            case "Delay": {
                if (this.packets.size() <= 100) break;
                this.poll();
                break;
            }
            case "SlowRelease": {
                if (this.packets.size() <= 100 && this.ticks % 5 != 0) break;
                this.poll();
            }
        }
    }

    private void poll() {
        if (this.packets.isEmpty()) {
            return;
        }
        this.sendTick(this.packets.getFirst());
        this.packets.removeFirst();
    }

    @Override
    public String getSuffix() {
        return modeValue.getConfigValue().toString();
    }

    private void sendTick(List<Packet<?>> tick) {
        tick.forEach(packet -> {
            mc.getNetHandler().getNetworkManager().sendPacketWithoutHigherPacket(packet);
            this.handleFakePlayerPacket(packet);
        });
    }

    private void handleFakePlayerPacket(Packet<?> packet) {
        if (packet instanceof C03PacketPlayer.C04PacketPlayerPosition) {
            C03PacketPlayer.C04PacketPlayerPosition position = (C03PacketPlayer.C04PacketPlayerPosition)packet;
            this.fakePlayer.setPositionAndRotation2(position.x, position.y, position.z, this.fakePlayer.rotationYaw, this.fakePlayer.rotationPitch, 3, true);
            this.fakePlayer.onGround = position.isOnGround();
        } else if (packet instanceof C03PacketPlayer.C05PacketPlayerLook) {
            C03PacketPlayer.C05PacketPlayerLook rotation = (C03PacketPlayer.C05PacketPlayerLook)packet;
            this.fakePlayer.setPositionAndRotation2(this.fakePlayer.posX, this.fakePlayer.posY, this.fakePlayer.posZ, rotation.getYaw(), rotation.getPitch(), 3, true);
            this.fakePlayer.onGround = rotation.isOnGround();
            this.fakePlayer.rotationYawHead = rotation.getYaw();
            this.fakePlayer.rotationYaw = rotation.getYaw();
            this.fakePlayer.rotationPitch = rotation.getPitch();
        } else if (packet instanceof C03PacketPlayer.C06PacketPlayerPosLook) {
            C03PacketPlayer.C06PacketPlayerPosLook positionRotation = (C03PacketPlayer.C06PacketPlayerPosLook)packet;
            this.fakePlayer.setPositionAndRotation2(positionRotation.x, positionRotation.y, positionRotation.z, positionRotation.getYaw(), positionRotation.getPitch(), 3, true);
            this.fakePlayer.onGround = positionRotation.isOnGround();
            this.fakePlayer.rotationYawHead = positionRotation.getYaw();
            this.fakePlayer.rotationYaw = positionRotation.getYaw();
            this.fakePlayer.rotationPitch = positionRotation.getPitch();
        } else if (packet instanceof C0BPacketEntityAction) {
            C0BPacketEntityAction action = (C0BPacketEntityAction)packet;
            if (action.getAction() == C0BPacketEntityAction.Action.START_SPRINTING) {
                this.fakePlayer.setSprinting(true);
            } else if (action.getAction() == C0BPacketEntityAction.Action.STOP_SPRINTING) {
                this.fakePlayer.setSprinting(false);
            } else if (action.getAction() == C0BPacketEntityAction.Action.START_SNEAKING) {
                this.fakePlayer.setSneaking(true);
            } else if (action.getAction() == C0BPacketEntityAction.Action.STOP_SNEAKING) {
                this.fakePlayer.setSneaking(false);
            }
        } else if (packet instanceof C0APacketAnimation) {
            C0APacketAnimation animation = (C0APacketAnimation)packet;
            this.fakePlayer.swingItem();
        }
    }

    @EventTarget
    public void onUpdate(EventUpdate event) {
        if (mc.thePlayer.hurtTime > 0 && this.autoclose.getConfigValue().booleanValue()) {
            this.toggle();
            NotificationManager.post(NotificationType.SUCCESS, "Blink", "AutoClose!", 5.0f);
        }
        if (countdownTicks > 0) {
            countdownTicks--;
        } else if (countdownTicks == 0) {
            this.toggle();
            countdownTicks = -1; // 重置计时器
        }
        if(skywars.getConfigValue()){
            mc.thePlayer.capabilities.allowEdit = true;
        }
    }


}

