package dev.tenacity.module.impl.combat;

import com.viaversion.viaversion.api.Via;
import com.viaversion.viaversion.api.protocol.packet.PacketWrapper;
import com.viaversion.viaversion.api.type.Type;
import com.viaversion.viaversion.protocols.protocol1_12_1to1_12.ServerboundPackets1_12_1;
import de.gerrygames.viarewind.protocol.protocol1_8to1_9.Protocol1_8TO1_9;
import de.gerrygames.viarewind.utils.PacketUtil;
import dev.tenacity.Tenacity;
import dev.tenacity.commands.impl.FriendCommand;
import dev.tenacity.event.impl.player.AttackEvent;
import dev.tenacity.event.impl.player.KeepSprintEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.event.impl.render.Render3DEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.render.HUDMod;
import dev.tenacity.module.impl.misc.Teams;
import dev.tenacity.module.impl.movement.Scaffold;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.module.settings.impl.MultipleBoolSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.MovementFix;
import dev.tenacity.utils.animations.Animation;
import dev.tenacity.utils.animations.Direction;
import dev.tenacity.utils.animations.impl.SmoothStepAnimation;
import dev.tenacity.utils.component.RotationComponent;
import dev.tenacity.utils.misc.MathUtils;
import dev.tenacity.utils.player.AimSimulator;
import dev.tenacity.utils.player.InventoryUtils;
import dev.tenacity.utils.player.RotationUtils;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.server.PacketUtils;
import dev.tenacity.utils.time.TimerUtil;
import dev.tenacity.utils.tuples.Pair;
import dev.tenacity.utils.vector.Vector2f;
import dev.tenacity.viamcp.ViaMCP;
import dev.tenacity.viamcp.protocols.ProtocolCollection;
import dev.tenacity.viamcp.utils.AttackOrder;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.monster.EntityMob;
import net.minecraft.entity.passive.EntityAnimal;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.*;
import net.minecraft.potion.Potion;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MathHelper;
import org.lwjgl.opengl.GL11;

import java.awt.*;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;


public final class KillAura extends Module {
    private int cps;
    private int targetIndex = 0;
    public static float yaw = 0.0F;
    public static boolean attacking;
    public static boolean blocking;
    public static boolean wasBlocking;
    public static EntityLivingBase target;
    private EntityLivingBase auraESPTarget;
    private final TimerUtil attackTimer = new TimerUtil();
    private final TimerUtil switchTimer = new TimerUtil();
    public static final List<EntityLivingBase> targets = new ArrayList<>();

    private static final MultipleBoolSetting targetsSetting = new MultipleBoolSetting("Targets",
            new BooleanSetting("Teams", true),//是队友不打反正打 //md写炸了
            new BooleanSetting("Players", true),
            new BooleanSetting("Animals", false),
            new BooleanSetting("Mobs", false),
            new BooleanSetting("Invisibles", false));

    private final ModeSetting mode = new ModeSetting("Mode", "Single", "Single", "Switch");
    public final NumberSetting switchDelay = new NumberSetting("SwitchDelay", 170, 1000.0, 0.0, 1.0);

    private final BooleanSetting rotations = new BooleanSetting("Rotations", true);
    private final NumberSetting rotationSpeed = new NumberSetting("Rotation speed", 5, 10, 2, 0.1);
    private final ModeSetting rotationMode = new ModeSetting("Rotation Mode", "HvH", "HvH", "Vanilla", "New", "Nearest");

    private final BooleanSetting autoBlock = new BooleanSetting("AutoBlock", false);
    private final ModeSetting autoBlockMode = new ModeSetting("AutoBlock Mode", "Grim", "Fake", "Grim","GrimC08","Watchdog", "Watchdog 1.12.2","1.17+");
    private final BooleanSetting fixNoSlowFlag = new BooleanSetting("Fix NoSlow flag", false);
    private final ModeSetting sortMode = new ModeSetting("Sort Mode", "Range", "Range", "Hurt Time", "Health", "Armor");
    public static final ModeSetting auraESP = new ModeSetting("Target ESP", "Capture", "Capture", "Round", "Circle", "Tracer", "Box", "Tracer", "None");

    private final NumberSetting minCPS = new NumberSetting("Min CPS", 10, 20, 1, 1);
    private final NumberSetting maxCPS = new NumberSetting("Max CPS", 20, 20, 1, 1);
    public static final NumberSetting reach = new NumberSetting("Reach", 4, 6, 3, 0.1);

    public static final ModeSetting movementFix = new ModeSetting("Movement fix", "Normal", "None", "Normal", "Strict");
    private final BooleanSetting KeepSprint = new BooleanSetting("Keep Sprint", false);
    private static final BooleanSetting ThroughWalls = new BooleanSetting("Through Walls", false);
    private final BooleanSetting RayCast = new BooleanSetting("Ray Cast", false);
    private final BooleanSetting circleValue = new BooleanSetting("Circle", false);

    private int autoBlock$watchdog$blockingTime = 0;
    private final NumberSetting circleAccuracy = new NumberSetting("CircleAccuracy", 15.0, 0.0, 60.0, 1.0);

    public KillAura() {
        super("KillAura", Category.COMBAT, "Automatically attacks players");
        autoBlockMode.addParent(autoBlock, a -> autoBlock.isEnabled());
        fixNoSlowFlag.addParent(autoBlockMode, m -> m.is("Watchdog"));
        this.switchDelay.addParent(this.mode, m -> this.mode.is("Switch"));
        this.rotationMode.addParent(this.rotations, BooleanSetting::isEnabled);
        this.rotationSpeed.addParent(this.rotations, BooleanSetting::isEnabled);
        this.addSettings(targetsSetting, mode, switchDelay, rotations, rotationMode, rotationSpeed, autoBlock, autoBlockMode, fixNoSlowFlag, auraESP, minCPS, maxCPS, reach, sortMode, movementFix, KeepSprint, ThroughWalls, RayCast, circleValue);
    }

    private void attack() {
        if (target != null) {
            this.attackEntity(target);
            if (mc.thePlayer.fallDistance > 0.0f && !mc.thePlayer.onGround && !mc.thePlayer.isOnLadder() && !mc.thePlayer.isInWater() && !mc.thePlayer.isPotionActive(Potion.blindness) && mc.thePlayer.ridingEntity == null) {
                mc.thePlayer.onCriticalHit(target);
            }
            if (EnchantmentHelper.getModifierForCreature(mc.thePlayer.getHeldItem(), target.getCreatureAttribute()) > 0.0f) {
                mc.thePlayer.onEnchantmentCritical(target);
                PacketUtils.sendPacket(new C0APacketAnimation());
            }
        }
    }

    private void attackEntity(final Entity target) {
        AttackOrder.sendFixedAttack(mc.thePlayer, target);
        this.attackTimer.reset();
    }

    @Override
    public void onDisable() {
        target = null;
        targets.clear();
        attacking = false;
        blocking = false;
        if (wasBlocking) {
            if (this.autoBlockMode.is("Grim")) {
                KillAura.mc.gameSettings.keyBindUseItem.pressed = false;
            } else if (this.autoBlockMode.is("Watchdog")) {
                PacketUtils.sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
            } else if (this.autoBlockMode.is("Watchdog 1.12.2")) {
                if (ViaMCP.getInstance().getVersion() >= ProtocolCollection.R1_12_2.getVersion().getVersion()) {
                    PacketUtils.sendPacketNoEvent(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
                }
            }
        }
        wasBlocking = false;
        autoBlock$watchdog$blockingTime = 0;
        super.onDisable();
    }
    public static void sendC08() {
        PacketWrapper useItem = PacketWrapper.create(29, null, Via.getManager().getConnectionManager().getConnections().iterator().next());
        useItem.write(Type.VAR_INT, 1);

        de.gerrygames.viarewind.utils.PacketUtil.sendToServer(useItem, Protocol1_8TO1_9.class, true, true);
    }
    @Override
    public void onMotionEvent(MotionEvent event) {
        this.setSuffix(mode.getMode());

        if (minCPS.getValue() > maxCPS.getValue()) {
            minCPS.setValue(minCPS.getValue() - 1);
        }

        if (Tenacity.INSTANCE.getModuleCollection().get(Scaffold.class).isEnabled()) return;
        // Gets all entities in specified range, sorts them using your specified sort mode, and adds them to target list

        this.sortTargets();
        if (target == null) {
            yaw = mc.thePlayer.rotationYaw;
        }

        if (event.isPre()) {
            attacking = !targets.isEmpty();
            blocking = autoBlock.isEnabled() && attacking && InventoryUtils.isHoldingSword();
            if (attacking) {
                if (mode.is("Switch")) {
                    if (switchTimer.hasTimeElapsed(switchDelay.getValue().intValue(), true)) {
                        targetIndex = (targetIndex + 1) % targets.size();
                    }
                    if (targetIndex < targets.size()) {
                        target = targets.get(targetIndex);
                    } else {
                        target = null;
                    }
                } else {
                    if (!targets.isEmpty()) {
                        target = targets.get(0);
                    } else {
                        target = null;
                    }
                }

                if (rotations.isEnabled()) {
                    float[] rotations = new float[]{0, 0};
                    final double minRotationSpeed = this.rotationSpeed.getValue();
                    final double maxRotationSpeed = this.rotationSpeed.getValue();
                    final float rotationSpeed = (float) MathUtils.getRandom(minRotationSpeed, maxRotationSpeed);
                    switch (rotationMode.getMode()) {
                        case "New":
                            if (target != null) {
                                rotations = RotationUtils.getXylitolRotation(target, reach.getValue() + 0.1);
                            }
                            break;
                        case "HvH":
                            if (target != null) {
                                rotations = RotationUtils.getHVHRotation(target, reach.getValue() + 0.1);
                            }
                            break;
                        case "Vanilla":
                            if (target != null) {
                                rotations = RotationUtils.getRotationsNeeded(KillAura.target);
                            }
                            break;
                        case "Nearest":
                            if (target != null) {
                                Pair<Float, Float> aimResult = AimSimulator.getLegitAim(target, mc.thePlayer, true, true, false, null, 0);
                                rotations = new float[]{
                                        aimResult.getFirst(),
                                        aimResult.getSecond()
                                };
                                break;

                            }

                    }
                    RotationComponent.setRotations(new Vector2f(rotations[0], rotations[1]), rotationSpeed, MovementFix.values()[movementFix.modes.indexOf(movementFix.getMode())]);
                }

                if (RayCast.isEnabled() && !RotationUtils.isMouseOver(event.getYaw(), event.getPitch(), target, reach.getValue().floatValue()))
                    return;

                if (attackTimer.hasTimeElapsed(cps, true)) {
                    final int maxValue = (int) ((minCPS.getMaxValue() - maxCPS.getValue()) * 5.0);
                    final int minValue = (int) ((minCPS.getMaxValue() - minCPS.getValue()) * 5.0);
                    cps = MathUtils.getRandomInRange(minValue, maxValue);
                    AttackEvent attackEvent = new AttackEvent(target);
                    Tenacity.INSTANCE.getEventProtocol().handleEvent(attackEvent);
                    attack();
                }

            } else {
                attackTimer.reset();
                target = null;
            }
        }

        if (blocking) {
            switch (this.autoBlockMode.getMode()) {
                case "Grim":
                    if (event.isPost()) {
                        if (mc.thePlayer.getHeldItem() != null && mc.thePlayer.getHeldItem().getItem() instanceof ItemSword) {
                            PacketUtils.sendC0F();
                            PacketWrapper useItem = PacketWrapper.create(29, null, Via.getManager().getConnectionManager().getConnections().iterator().next());
                            useItem.write(Type.VAR_INT, 1);
                            de.gerrygames.viarewind.utils.PacketUtil.sendToServer(useItem, Protocol1_8TO1_9.class, true, true);
                            wasBlocking = true;
                            mc.gameSettings.keyBindUseItem.pressed = true;
                        }
                    }
                    break;
                case "Watchdog":
                    if (event.isPre()) {
                        if (autoBlock$watchdog$blockingTime < 10 || !fixNoSlowFlag.isEnabled()) {
                            PacketUtils.sendPacket(new C02PacketUseEntity(target, C02PacketUseEntity.Action.INTERACT));
                            PacketUtils.sendPacket(new C08PacketPlayerBlockPlacement(mc.thePlayer.getHeldItem()));
                            wasBlocking = true;
                            autoBlock$watchdog$blockingTime++;
                        } else {
                            if (wasBlocking) {
                                PacketUtils.sendPacket(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
                            }
                            wasBlocking = false;
                            autoBlock$watchdog$blockingTime = 0;
                        }
                    }
                    break;
                case "Watchdog 1.12.2":
                    if (event.isPre()) {
                        if (ViaMCP.getInstance().getVersion() >= ProtocolCollection.R1_12_2.getVersion().getVersion()) {
                            PacketUtils.sendPacket(new C08PacketPlayerBlockPlacement(new BlockPos(-1, -1, -1), 255, mc.thePlayer.inventory.getCurrentItem(), 0.0F, 0.0F, 0.0F));
                            PacketWrapper useItem = PacketWrapper.create(ServerboundPackets1_12_1.USE_ITEM, null, Via.getManager().getConnectionManager().getConnections().iterator().next());
                            useItem.write(Type.VAR_INT, 1);
                            PacketUtil.sendToServer(useItem, Protocol1_8TO1_9.class, true, true);
                            wasBlocking = true;
                        }
                    }
                    break;
                case "GrimC08": {
                    if (event.isPost()) {
                        mc.getNetHandler().addToSendQueue(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getCurrentItem()));
                    }
                }
                case "1.17+":
                    int slot = KillAura.mc.thePlayer.inventory.currentItem;
                    PacketUtils.sendPacket(new C09PacketHeldItemChange(slot % 8 + 1));
                    PacketUtils.sendPacket(new C09PacketHeldItemChange(slot));
                    wasBlocking=false;
                case "Fake":
                    break;
            }
        } else if (wasBlocking && this.autoBlockMode.is("Grim") && event.isPre()) {
            KillAura.mc.gameSettings.keyBindUseItem.pressed = false;
            wasBlocking = false;
        } else if (wasBlocking && this.autoBlockMode.is("Watchdog") && event.isPre()) {
            PacketUtils.sendPacketNoEvent(new C07PacketPlayerDigging(C07PacketPlayerDigging.Action.RELEASE_USE_ITEM, BlockPos.ORIGIN, EnumFacing.DOWN));
            wasBlocking = false;
        }
    }

    public void sortTargets() {
        targets.clear();
        for (Entity entity : mc.theWorld.getLoadedEntityList()) {
            if (entity instanceof EntityLivingBase) {
                EntityLivingBase entityLivingBase = (EntityLivingBase) entity;
                if (mc.thePlayer.getDistanceToEntity(entity) <= reach.getValue() && isValid(entity) && mc.thePlayer != entityLivingBase && !FriendCommand.isFriend(entityLivingBase.getName()) && !AntiBot.isServerBot(entity)) {
                    targets.add(entityLivingBase);
                }
            }
        }
        switch (sortMode.getMode()) {
            case "Range":
                targets.sort(Comparator.comparingDouble(mc.thePlayer::getDistanceToEntity));
                break;
            case "Hurt Time":
                targets.sort(Comparator.comparingInt(EntityLivingBase::getHurtTime));
                break;
            case "Health":
                targets.sort(Comparator.comparingDouble(EntityLivingBase::getHealth));
                break;
            case "Armor":
                targets.sort(Comparator.comparingInt(EntityLivingBase::getTotalArmorValue));
                break;
        }
    }

    public static boolean isValid(Entity entity) {
        if (entity instanceof EntityPlayer && targetsSetting.getSetting("Teams").isEnabled() && targetsSetting.isEnabled("Players") && !Teams.check((EntityLivingBase) entity))
            return true;

        if (entity instanceof EntityPlayer && targetsSetting.getSetting("Players").isEnabled() && !entity.isInvisible() && mc.thePlayer.canEntityBeSeen(entity))
            return true;

        if (entity instanceof EntityPlayer && targetsSetting.getSetting("Invisibles").isEnabled() && entity.isInvisible())
            return true;

        if (entity instanceof EntityPlayer && ThroughWalls.isEnabled() && !mc.thePlayer.canEntityBeSeen(entity))
            return true;

        if (entity instanceof EntityAnimal && targetsSetting.getSetting("Animals").isEnabled())
            return true;

        if (entity instanceof EntityMob && targetsSetting.getSetting("Mobs").isEnabled())
            return true;

        return entity.isInvisible() && targetsSetting.getSetting("Invisibles").isEnabled();
    }

    @Override
    public void onKeepSprintEvent(KeepSprintEvent event) {
        if (KeepSprint.isEnabled()) {
            event.cancel();
        }
    }

    private final Animation auraESPAnim = new SmoothStepAnimation(650, 1);


    @Override
    public void onAttackEvent(AttackEvent event) {
        if (event.getTargetEntity() != null) {
            try {
                auraESPTarget = event.getTargetEntity();
            } catch (ClassCastException e) {
                auraESPTarget = null;
            }
        }
    }

    @Override
    public void onRender3DEvent(Render3DEvent event) {
        if (circleValue.isEnabled()) {
            GL11.glPushMatrix();
            GL11.glTranslated(KillAura.mc.thePlayer.lastTickPosX + (KillAura.mc.thePlayer.posX - KillAura.mc.thePlayer.lastTickPosX) * (double) KillAura.mc.timer.renderPartialTicks - KillAura.mc.getRenderManager().renderPosX, KillAura.mc.thePlayer.lastTickPosY + (KillAura.mc.thePlayer.posY - KillAura.mc.thePlayer.lastTickPosY) * (double) KillAura.mc.timer.renderPartialTicks - KillAura.mc.getRenderManager().renderPosY, KillAura.mc.thePlayer.lastTickPosZ + (KillAura.mc.thePlayer.posZ - KillAura.mc.thePlayer.lastTickPosZ) * (double) KillAura.mc.timer.renderPartialTicks - KillAura.mc.getRenderManager().renderPosZ);
            GL11.glEnable(3042);
            GL11.glEnable(2848);
            GL11.glDisable(3553);
            GL11.glDisable(2929);
            GL11.glBlendFunc(770, 771);
            GL11.glLineWidth(1.0f);
            GL11.glRotatef(90.0f, 1.0f, 0.0f, 0.0f);
            GL11.glBegin(3);
            int i = 0;
            while (i <= 360) {
                GL11.glVertex2f((float) (Math.cos((double) i * Math.PI / 180.0) * (double) reach.getValue().floatValue()), (float) (Math.sin((double) i * Math.PI / 180.0) * (double) reach.getValue().floatValue()));
                i = (int) ((double) i + (61.0 - this.circleAccuracy.getValue()));
            }
            GL11.glVertex2f((float) (Math.cos(Math.PI * 2) * (double) reach.getValue().floatValue()), (float) (Math.sin(Math.PI * 2) * (double) reach.getValue().floatValue()));
            GL11.glEnd();
            GL11.glDisable(3042);
            GL11.glEnable(3553);
            GL11.glEnable(2929);
            GL11.glDisable(2848);
            GL11.glPopMatrix();
        }

        auraESPAnim.setDirection(target != null ? Direction.FORWARDS : Direction.BACKWARDS);

        if (target != null) {
            auraESPTarget = target;
        }

        if (auraESPAnim.finished(Direction.BACKWARDS)) {
            auraESPTarget = null;
        }

        Color color = HUDMod.getClientColors().getFirst();
        Color color2 = HUDMod.getClientColors().getSecond();
        float dst = mc.thePlayer.getSmoothDistanceToEntity(auraESPTarget);

        if (auraESPTarget != null) {
            if (auraESP.is("Box")) {
                RenderUtil.renderBoundingBox(auraESPTarget, color, auraESPAnim.getOutput().floatValue());
            }
            if (auraESP.is("Circle")) {
                RenderUtil.drawCircle(auraESPTarget, event.getTicks(), .75f, color.getRGB(), auraESPAnim.getOutput().floatValue());
            }
            if (auraESP.is("Tracer")) {
                RenderUtil.drawTracerLine(auraESPTarget, 4f, Color.BLACK, auraESPAnim.getOutput().floatValue());
                RenderUtil.drawTracerLine(auraESPTarget, 2.5f, color, auraESPAnim.getOutput().floatValue());
            }
            try {
                RenderUtil.drawTargetESP2D(Objects.requireNonNull(RenderUtil.targetESPSPos(auraESPTarget)).x, Objects.requireNonNull(RenderUtil.targetESPSPos(auraESPTarget)).y, color, color2,
                        (1.0f - MathHelper.clamp_float(Math.abs(dst - 6.0f) / 60.0f, 0f, 0.75f)) * 1, targetIndex, auraESPAnim.getOutput().floatValue());
            } catch (Exception e) {
                auraESPTarget = null;
            }
        }
    }
}
