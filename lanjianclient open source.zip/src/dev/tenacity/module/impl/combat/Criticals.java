package dev.tenacity.module.impl.combat;

import dev.tenacity.event.impl.network.PacketReceiveEvent;
import dev.tenacity.event.impl.network.PacketSendEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.event.impl.player.MoveEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.Setting;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.component.RotationComponent;
import dev.tenacity.utils.misc.MathUtils;
import dev.tenacity.utils.player.RayCastUtil;
import dev.tenacity.utils.player.RotationUtils;
import dev.tenacity.utils.server.PacketUtils;
import dev.tenacity.utils.time.TimerUtil;
import net.minecraft.init.Blocks;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C07PacketPlayerDigging;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.util.EnumFacing;

import java.util.concurrent.ConcurrentLinkedQueue;

@SuppressWarnings("unused")
public final class Criticals extends Module {
    private boolean jumping = false;
    private boolean stage;
    private double offset;
    private int groundTicks;
    private boolean air = false;

    final ConcurrentLinkedQueue<Packet<?>> packets = new ConcurrentLinkedQueue<>();
    private final ModeSetting mode = new ModeSetting("Mode", "Legit","Stuck","Legit");
    private final NumberSetting delay = new NumberSetting("Delay",0,1000,0,1);
    private final NumberSetting reduce = new NumberSetting("Timer Reduce",0.6,2,0,0.1);
    private final BooleanSetting badpackete = new BooleanSetting("BadPacketE Disabler",true);
    private final TimerUtil timer = new TimerUtil();

    public Criticals() {
        super("Criticals", Category.COMBAT, "22666j jua the dog shit");
        this.addSettings(mode,delay,reduce,badpackete);
        Setting.addParent(mode, m -> m.is("Stuck"), delay);
        Setting.addParent(mode, m -> m.is("Stuck"), reduce);
        Setting.addParent(mode, m -> m.is("Stuck"), badpackete);
        this.setSuffix(mode.getMode());
    }

    @Override
    public void onMotionEvent(MotionEvent e) {
        if (mode.getMode().equals("Legit")) {
            if(mc.thePlayer.fallDistance > 0 && KillAura.target != null) {
                if (timer.hasTimeElapsed(delay.getValue())) {
                    timer.reset();
                    sendc03Packet();
                }
            }else{
                timer.reset();
            }
        }
    }
    private  void sendc03Packet(){
        mc.timer.lastSyncSysClock += MathUtils.getRandom(32052, 89505);
        mc.timer.elapsedPartialTicks = (float)((double)mc.timer.elapsedPartialTicks - reduce.getValue());
        if(badpackete.isEnabled()) ++mc.thePlayer.positionUpdateTicks;
        PacketUtils.sendPacket(new C03PacketPlayer(mc.thePlayer.onGround));
    }
}
