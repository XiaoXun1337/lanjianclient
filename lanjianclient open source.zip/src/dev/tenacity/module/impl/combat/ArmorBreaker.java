package dev.tenacity.module.impl.combat;

import dev.tenacity.event.impl.network.PacketSendEvent;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.utils.player.InventoryUtils;
import dev.tenacity.utils.server.PacketUtils;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemSword;
import net.minecraft.network.play.client.C02PacketUseEntity;
import net.minecraft.network.play.client.C09PacketHeldItemChange;
import net.minecraft.network.play.client.C0EPacketClickWindow;

public class ArmorBreaker extends Module {


    public ArmorBreaker() {
        super("ArmorBreaker", Category.COMBAT,"Increase damage by switching items");
        addSettings(你妈大逼);
    }
    private static final ModeSetting 你妈大逼 = new ModeSetting("SwitchMode","WindowClick","WindowClick","Packet");
    int slot = -1;
    boolean back = false;
    @Override
    public void onPacketSendEvent(PacketSendEvent e) {
        if(e.getPacket() instanceof C02PacketUseEntity && ((C02PacketUseEntity) e.getPacket()).getAction() == C02PacketUseEntity.Action.ATTACK){;
            e.setCancelled(true);
            switchBestSword();

            操逼(
                    mc.thePlayer.openContainer.windowId,
                    slot,
                    mc.thePlayer.inventory.currentItem,
                    2,
                    mc.thePlayer
            );

            PacketUtils.sendNoEvent(e.getPacket());
            switchSwordUnUsed();
        }
    }
    @Override
    public void onMotionEvent(MotionEvent e) {
        switchBestSword();
    }

    private void switchBestSword() {
        float damage = 1;
        int bestItem = -1;
        for (int i = 0; i < 45; i++) {
            ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
            if (is != null && is.getItem() instanceof ItemSword && InventoryUtils.getSwordStrength(is) > damage) {
                damage = InventoryUtils.getSwordStrength(is);
                bestItem = i;
            }
        }
        if (bestItem != -1) {
            slot = bestItem;
        }
    }
    private void switchSwordUnUsed() {
        int bestItem = -1;
        for (int i = 0; i < 36; i++) {
            ItemStack is = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
            if (is != null && is.getItem() instanceof ItemSword && i != slot) {
                bestItem = i;
            }
        }
        if (bestItem != -1) {
            操逼(
                    mc.thePlayer.openContainer.windowId,
                    bestItem,
                    mc.thePlayer.inventory.currentItem,
                    2,
                    mc.thePlayer
            );
            back = false;
        }
    }
    private void 操逼(int 操, int 射, int 擦, int 干, EntityPlayer 你妈) {
        if (你妈大逼.getMode().equals("WindowClick")) {
            mc.playerController.windowClick(
                    操,
                    射,
                    擦,
                    干,
                    你妈
            );
        }
        if (你妈大逼.getMode().equals("Packet")) {

            short 男同 = 你妈.openContainer.getNextTransactionID(你妈.inventory);
            ItemStack 药娘 = 你妈.openContainer.slotClick(射, 擦, 干, 你妈);

            PacketUtils.sendPacket(new C0EPacketClickWindow(操, 射, 擦, 干, 药娘, 男同));
        }
    }
}
