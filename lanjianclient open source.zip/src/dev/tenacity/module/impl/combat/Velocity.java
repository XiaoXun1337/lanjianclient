package dev.tenacity.module.impl.combat;


import de.gerrygames.viarewind.utils.PacketUtil;
import dev.tenacity.event.EventTarget;
import dev.tenacity.event.impl.network.PacketReceiveEvent;
import dev.tenacity.event.impl.network.PacketSendEvent;
import dev.tenacity.event.impl.player.UpdateEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.MovementFix;
import dev.tenacity.utils.player.ChatUtil;
import dev.tenacity.utils.player.MovementUtils;
import dev.tenacity.utils.server.PacketUtils;
import dev.tenacity.viamcp.utils.AttackOrder;
import net.minecraft.network.Packet;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.network.play.server.S08PacketPlayerPosLook;
import net.minecraft.network.play.server.S12PacketEntityVelocity;
import net.minecraft.network.play.server.S27PacketExplosion;

import org.lwjgl.input.Keyboard;




public class Velocity extends Module {

    private final ModeSetting mode = new ModeSetting("Mode", "Grim", new String[] {"Grim", "Watchdog"});
    private final NumberSetting vertical = new NumberSetting("Vertical", 0, 100, 0, 10);
    private final NumberSetting horizontal = new NumberSetting("Horizontal", 0, 100, 0, 10);
    private final NumberSetting times = new NumberSetting("Attack Times", 1, 15, 0, 1);

    public static boolean velocity = false;
    public static int velocityTicks ;
    public static int velocityAirTicks;
    public static boolean velocityinput = false;
    boolean lastSprinting;

    public Velocity() {
        super("Velocity", Category.COMBAT,"Good");
        this.addSettings(mode, vertical, horizontal, times);
    }

    @Override
    public void onEnable() {
        velocity = false;
        super.onEnable();
    }
    @Override
    public void onDisable() {
        velocity = false;
        super.onDisable();
    }

    @EventTarget
    public void onPacketReceiveEvent(PacketReceiveEvent e) {
        this.setSuffix(mode.getConfigValue());
        if (mode.is("Watchdog")) {
            if (e.getPacket() instanceof S12PacketEntityVelocity) {
                S12PacketEntityVelocity packet = (S12PacketEntityVelocity) e.getPacket();

                if (packet.getEntityID() == mc.thePlayer.getEntityId()) {
                    if(horizontal.getValue() == 0f && vertical.getValue() == 0f){
                        e.setCancelled(true);
                    }
                    else {
                        packet.motionX = ((int) (packet.getMotionX() * horizontal.getValue() / 100.0));
                        packet.motionY = ((int) (packet.getMotionY() * vertical.getValue() / 100.0));
                        packet.motionZ = ((int) (packet.getMotionZ() * horizontal.getValue() / 100.0));
                    }
                }
            }

            //hypixel fucker
            if (e.getPacket() instanceof S27PacketExplosion) {
                handle(e);
            }
        }
        if (mode.is("Grim")) {
            if (e.getPacket() instanceof S12PacketEntityVelocity) {
                S12PacketEntityVelocity packet = (S12PacketEntityVelocity) e.getPacket();
                if (packet.getEntityID() == mc.thePlayer.getEntityId()) {
                    if (mc.thePlayer.isInWeb) {
                        ChatUtil.send("Ignore: Player is in Web!");
                    } else {
                        velocityinput = true;

                        if (KillAura.target != null) {
                            boolean needSprint = !mc.thePlayer.serverSprintState;
                            if (needSprint) {

                                PacketUtils.sendPacket(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.START_SPRINTING));
                            }
                            for (int i = 0; i < times.getValue(); i++) {

                                AttackOrder.sendFixedAttack(mc.thePlayer, KillAura.target);

                            }
                            if (needSprint) {
                                // PacketUtils.sendPacketNoEvent(new C03PacketPlayer(mc.thePlayer.onGround));
                                PacketUtils.sendPacket(new C0BPacketEntityAction(mc.thePlayer, C0BPacketEntityAction.Action.STOP_SPRINTING));
                            }

                            packet.motionZ *= 0.077760000;
                            packet.motionX *= 0.077760000;
                            velocity = true;
                        }
                    }
                }
            }

            if (e.getPacket() instanceof S08PacketPlayerPosLook) {
                velocity = false;
            }
        }
    }

    @EventTarget
    public void onPacketSendEvent(PacketSendEvent e) {
        final Packet<?> packet = (Packet<?>)e.getPacket();

        if (mode.is("Grim")) {
            if (e.getPacket() instanceof C0BPacketEntityAction) {
                if (((C0BPacketEntityAction) packet).getAction() == C0BPacketEntityAction.Action.START_SPRINTING) {
                    if (this.lastSprinting) {
                        e.setCancelled(true);
                    }
                    this.lastSprinting = true;
                } else if (((C0BPacketEntityAction) packet).getAction() == C0BPacketEntityAction.Action.STOP_SPRINTING) {
                    if (!this.lastSprinting) {
                        e.setCancelled(true);
                    }
                    this.lastSprinting = false;
                }
            }
        }
    }

    @EventTarget
    public void onMotionEvent(UpdateEvent event) {
        if (mode.is("Grim")) {
            if (event.isPost()) {
                velocityTicks++;
                if (!mc.thePlayer.onGround) {
                    velocityAirTicks++;
                    if (velocityAirTicks == 1) {
                        mc.gameSettings.keyBindForward.pressed = false;
                        mc.gameSettings.keyBindSprint.pressed = false;
                        mc.gameSettings.keyBindJump.pressed = false;
                    }
                    if (velocityAirTicks == 2) {
                        mc.thePlayer.setSprinting(false);
                        mc.gameSettings.keyBindForward.pressed = Keyboard.isKeyDown(mc.gameSettings.keyBindForward.getKeyCode());
                    }
                }
                if (velocity && (MovementUtils.isOnGround(0.01) || velocityTicks > 20)) {
                    velocity = false;
                }
            }
        }
    }

    public void handle(PacketReceiveEvent event) {
        S27PacketExplosion packet = (S27PacketExplosion) event.getPacket();

        if(horizontal.getValue() == 0f && vertical.getValue() == 0f){
            event.setCancelled(true);
        } else {
            packet.motionX = (float) (packet.getMotionX() * horizontal.getValue() / 100.0f);
            packet.motionY = (float) (packet.getMotionY() * vertical.getValue() / 100.0f);
            packet.motionZ = (float) (packet.getMotionZ() * horizontal.getValue() / 100.0f);
        }
    }
}
