package dev.tenacity.module.impl.combat.gapple;


import dev.tenacity.event.Event;

/**
 * @author Patrick
 * @since 11/17/2021
 */
public class PreUpdateEvent extends Event {

}
