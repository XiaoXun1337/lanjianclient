package dev.tenacity.module.impl.combat;

import dev.tenacity.event.impl.game.TickEvent;
import dev.tenacity.event.impl.render.Render2DEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.combat.gapple.GappleUtils;
import dev.tenacity.utils.player.ChatUtil;
import dev.tenacity.utils.player.MoveUtil;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.*;
import net.minecraft.util.ResourceLocation;

public class AutoGapple extends Module {
    public AutoGapple(){
        super("AutoGapple", Category.COMBAT, "sakdlwa");
    }

    private int sendDelay = 9;
    private int sendOnceTicks = 1;
    private boolean stopMove = true;
    public boolean noCancelC02 = false;
    public boolean noC02 = true;
    private boolean autoGapple = false;
    private int slot = -1;
    private int c03s = 0;
    private int c02s = 0;
    private boolean canStart = false;
    public static boolean eating = false;
    public static boolean pulsing = false;
    @Override
    public void onEnable() {
        this.c03s = 0;
        this.slot = this.findItem(36, 45, Items.golden_apple);
        if (this.slot != -1) {
            this.slot -= 36;
        }
    }

    @Override
    public void onDisable() {
        eating = false;
        if (this.canStart) {
            pulsing = false;
            GappleUtils.stopBlink();
        }
        if (this.stopMove) {
            MoveUtil.resetMove();
        }
    }
    @Override
    public void onTickEvent(TickEvent event){
        if (mc.thePlayer == null || mc.thePlayer.isDead) {
            GappleUtils.stopBlink();
            this.setEnabled(false);
            return;
        }
        if (this.slot == -1) {
            ChatUtil.print("你有苹果吗你就开");
            this.setEnabled(false);
            return;
        }
        if (eating) {
            if (this.stopMove) {
                MoveUtil.cancelMove();
            }
            if (!GappleUtils.blinking) {
                GappleUtils.blink(C09PacketHeldItemChange.class, C0EPacketClickWindow.class, C0DPacketCloseWindow.class);
                GappleUtils.setCancelReturnPredicate(C07PacketPlayerDigging.class, it -> ((C07PacketPlayerDigging)it).getStatus() == C07PacketPlayerDigging.Action.RELEASE_USE_ITEM);
                GappleUtils.setCancelReturnPredicate(C08PacketPlayerBlockPlacement.class, it -> ((C08PacketPlayerBlockPlacement)it).getPosition().getY() == -1);
                GappleUtils.setCancelReturnPredicate(C02PacketUseEntity.class, it -> this.noCancelC02);
                GappleUtils.setCancelReturnPredicate(C0APacketAnimation.class, it -> this.noCancelC02);
                GappleUtils.setCancelAction(C03PacketPlayer.class, packet -> ++this.c03s);
                GappleUtils.setReleaseAction(C03PacketPlayer.class, packet -> --this.c03s);
                GappleUtils.setReleaseReturnPredicateMap(C02PacketUseEntity.class, packet -> !eating && this.noC02);
                GappleUtils.setCancelAction(C02PacketUseEntity.class, packet -> ++this.c02s);
                GappleUtils.setReleaseAction(C02PacketUseEntity.class, packet -> --this.c02s);
                this.canStart = true;
            }
        } else {
            eating = true;
        }
        if (this.c03s >= 32) {
            eating = false;
            pulsing = true;
            GappleUtils.resetBlackList();
            GappleUtils.sendPacket(new C09PacketHeldItemChange(this.slot), true);
            GappleUtils.sendPacket(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventoryContainer.getSlot(this.slot + 36).getStack()), true);
            GappleUtils.stopBlink();
            GappleUtils.sendPacket(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem), true);
            pulsing = false;
            if (this.autoGapple) {
                this.c03s = 0;
                this.slot = this.findItem(36, 45, Items.golden_apple);
                if (this.slot != -1) {
                    this.slot -= 36;
                }
            } else {
                this.setEnabled(false);
            }
            return;
        }
        if (mc.thePlayer.ticksExisted % this.sendDelay == 0) {
            for (int i = 0; i < this.sendOnceTicks; ++i) {
                GappleUtils.releasePacket(true);
            }
            ChatUtil.print(String.valueOf(c03s));
        }
    }

    private int findItem(int startSlot, int endSlot, Item item) {
        for (int i = startSlot; i < endSlot; ++i) {
            ItemStack stack = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
            if (stack == null || stack.getItem() != item) continue;
            return i;
        }
        return -1;
    }
}
