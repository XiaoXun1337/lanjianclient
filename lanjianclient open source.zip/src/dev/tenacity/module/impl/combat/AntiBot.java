package dev.tenacity.module.impl.combat;


import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.game.WorldEvent;
import dev.tenacity.event.impl.network.PacketReceiveEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.ModeSetting;
import dev.tenacity.utils.player.PlayerUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.network.Packet;
import net.minecraft.network.play.server.S02PacketChat;
import net.minecraft.network.play.server.S14PacketEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AntiBot
        extends Module {
    private static final BooleanSetting entityID = new BooleanSetting("EntityID", false);
    private static final BooleanSetting sleep = new BooleanSetting("Sleep", false);
    private static final BooleanSetting noArmor = new BooleanSetting("NoArmor", false);
    private static final BooleanSetting height = new BooleanSetting("Height", false);
    private static final BooleanSetting ground = new BooleanSetting("Ground", false);
    private static final BooleanSetting dead = new BooleanSetting("Dead", false);
    private static final BooleanSetting health = new BooleanSetting("Health", false);
    private static final BooleanSetting hytGetNames = new BooleanSetting("HytGetName", false);
    private final BooleanSetting tips = new BooleanSetting("HytGetNameTips", false);
    private static final ModeSetting hytGetNameModes = new ModeSetting("HytGetNameMode", "hytGetNameMode.HytBedWars4v4",   "HytBedWars4v4",
           "HytBedWars1v1",
          "HytBedWars32",
            "HytBedWars16");
    private static final List<Integer> groundBotList = new ArrayList<>();
    private static final List<String> playerName = new ArrayList<>();

    public AntiBot() {
        super("AntiBot", Category.COMBAT, "Fuck You!!!!");
        this.addSettings(entityID, sleep,noArmor,height,ground,dead,health,hytGetNames,hytGetNameModes,tips);
    }

    @Override
    public void onWorldEvent(WorldEvent event) {
        this.clearAll();
    }

    private void clearAll() {
        playerName.clear();
    }

    @Override
    public void onPacketReceiveEvent(PacketReceiveEvent event) {
        Entity entity;
        if (AntiBot.mc.thePlayer == null || AntiBot.mc.theWorld == null) {
            return;
        }
        Packet<?> packet = event.getPacket();
        if (event.getPacket() instanceof S14PacketEntity && ground.isEnabled() && (entity = ((S14PacketEntity) event.getPacket()).getEntity(AntiBot.mc.theWorld)) instanceof EntityPlayer && ((S14PacketEntity) event.getPacket()).getOnGround() && !groundBotList.contains(entity.getEntityId())) {
            groundBotList.add(entity.getEntityId());
        }
        if (hytGetNames.isEnabled() && packet instanceof S02PacketChat) {
            if (((S02PacketChat) packet).getChatComponent().getUnformattedText().contains("获得胜利!") ||((S02PacketChat) packet).getChatComponent().getUnformattedText().contains("游戏开始 ...")) {
                this.clearAll();
            }
            switch (hytGetNameModes.getMode()) {
                case "HytBedWars4v4":
                case "HytBedWars1v1":
                case "HytBedWars32": {
                    String name;
                    Matcher matcher = Pattern.compile("杀死了 (.*?)\\(").matcher(((S02PacketChat) packet).getChatComponent().getUnformattedText());
                    Matcher matcher2 = Pattern.compile("起床战争>> (.*?) (\\((((.*?) 死了!)))").matcher(((S02PacketChat) packet).getChatComponent().getUnformattedText());
                    if ((matcher.find() && !((S02PacketChat) packet).getChatComponent().getUnformattedText().contains(": 起床战争>>") || !((S02PacketChat) packet).getChatComponent().getUnformattedText().contains(": 杀死了")) && !(name = matcher.group(1).trim()).isEmpty()) {
                        playerName.add(name);
                        if (this.tips.isEnabled()) {
                            PlayerUtil.log("§8[§c§l" + "Rain" + "Tips§8]§c§dAddBot：" + name);
                        }
                        String finalName = name;
                        new Thread(() -> {
                            try {
                                Thread.sleep(6000L);
                                playerName.remove(finalName);
                                if (this.tips.isEnabled()) {
                                    PlayerUtil.log("§8[§c§l" + "Rain" + "Tips§8]§c§dRemovedBot：" + finalName);
                                }
                            } catch (InterruptedException ex) {
                                ex.printStackTrace();
                            }
                        }).start();
                    }
                    if ((!matcher2.find() ||  ((S02PacketChat) packet).getChatComponent().getUnformattedText().contains(": 起床战争>>")) && ((S02PacketChat) packet).getChatComponent().getUnformattedText().contains(": 杀死了") || (name = matcher2.group(1).trim()).isEmpty())
                        break;
                    playerName.add(name);
                    if (this.tips.isEnabled()) {
                        PlayerUtil.log("§8[§c§l" +  "Rain" + "Tips§8]§c§dAddBot：" + name);
                    }
                    String finalName1 = name;
                    new Thread(() -> {
                        try {
                            Thread.sleep(6000L);
                            playerName.remove(finalName1);
                            if (this.tips.isEnabled()) {
                                PlayerUtil.log("§8[§c§l" + "Rain" + "Tips§8]§c§dRemovedBot：" + finalName1);
                            }
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        }
                    }).start();
                    break;
                }
                case "HytBedWars16": {
                    String name;
                    Matcher matcher = Pattern.compile("击败了 (.*?)!").matcher( ((S02PacketChat) packet).getChatComponent().getUnformattedText());
                    Matcher matcher2 = Pattern.compile("玩家 (.*?)死了！").matcher(((S02PacketChat) packet).getChatComponent().getUnformattedText());
                    if ((matcher.find() && !((S02PacketChat) packet).getChatComponent().getUnformattedText().contains(": 击败了") || !((S02PacketChat) packet).getChatComponent().getUnformattedText().contains(": 玩家 ")) && !(name = matcher.group(1).trim()).isEmpty()) {
                        playerName.add(name);
                        if (this.tips.isEnabled()) {
                            PlayerUtil.log("§8[§c§l" +"Rain" + "Tips§8]§c§dAddBot：" + name);
                        }
                        String finalName = name;
                        new Thread(() -> {
                            try {
                                Thread.sleep(10000L);
                                playerName.remove(finalName);
                                if (this.tips.isEnabled()) {
                                    PlayerUtil.log("§8[§c§l" + "Rain" + "Tips§8]§c§dRemovedBot：" + finalName);
                                }
                            } catch (InterruptedException ex) {
                                ex.printStackTrace();
                            }
                        }).start();
                    }
                    if ((!matcher2.find() || ((S02PacketChat) packet).getChatComponent().getUnformattedText().contains(": 击败了")) && ((S02PacketChat) packet).getChatComponent().getUnformattedText().contains(": 玩家 ") || (name = matcher2.group(1).trim()).isEmpty())
                        break;
                    playerName.add(name);
                    PlayerUtil.log("§8[§c§l" + "Rain" + "Tips§8]§c§dAddBot：" + name);
                    String finalName1 = name;
                    new Thread(() -> {
                        try {
                            Thread.sleep(10000L);
                            playerName.remove(finalName1);
                            PlayerUtil.log("§8[§c§l" + "Rain" + "Tips§8]§c§dRemovedBot：" + finalName1);
                        } catch (InterruptedException ex) {
                            ex.printStackTrace();
                        }
                    }).start();
                    break;
                }
            }
        }
    }

    public static boolean isServerBot(Entity entity) {
        if (Objects.requireNonNull(Tenacity.INSTANCE.getModuleCollection().getModule(AntiBot.class)).isEnabled() && entity instanceof EntityPlayer) {
            if (hytGetNames.isEnabled() && playerName.contains(entity.getName())) {
                return true;
            }
            if (height.isEnabled() && ((double) entity.height <= 0.5 || ((EntityPlayer) entity).isPlayerSleeping() || entity.ticksExisted < 80)) {
                return true;
            }
            if (dead.isEnabled() && entity.isDead) {
                return true;
            }
            if (health.isEnabled() && ((EntityPlayer) entity).getHealth() == 0.0f) {
                return true;
            }
            if (sleep.isEnabled() && ((EntityPlayer) entity).isPlayerSleeping()) {
                return true;
            }
            if (entityID.isEnabled() && (entity.getEntityId() >= 1000000000 || entity.getEntityId() <= -1)) {
                return true;
            }
            if (ground.isEnabled() && !groundBotList.contains(entity.getEntityId())) {
                return true;
            }
            return noArmor.isEnabled() && ((EntityPlayer) entity).inventory.armorInventory[0] == null && ((EntityPlayer) entity).inventory.armorInventory[1] == null && ((EntityPlayer) entity).inventory.armorInventory[2] == null && ((EntityPlayer) entity).inventory.armorInventory[3] == null;
        }
        return false;
    }

}