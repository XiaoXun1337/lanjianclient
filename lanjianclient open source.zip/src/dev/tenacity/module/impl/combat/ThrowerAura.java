package dev.tenacity.module.impl.combat;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.player.MotionEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.impl.misc.Teams;
import dev.tenacity.module.impl.movement.Scaffold;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.NumberSetting;
import dev.tenacity.utils.MovementFix;
import dev.tenacity.utils.component.RotationComponent;
import dev.tenacity.utils.player.RotationUtils;
import dev.tenacity.utils.time.TimerUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.entity.projectile.EntityFishHook;
import net.minecraft.init.Items;
import net.minecraft.item.ItemStack;
import net.minecraft.network.play.client.C08PacketPlayerBlockPlacement;
import net.minecraft.network.play.client.C09PacketHeldItemChange;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;



public class ThrowerAura extends Module {
    private final NumberSetting fov = new NumberSetting("Fov",150.0,180.0,90.0,0.1);

    private final NumberSetting range = new NumberSetting("Range",5.0,10.0,3.0,0.1);

    private final NumberSetting delay = new NumberSetting("Delay",20.0,1000.0,0.0,1);

   private final BooleanSetting fishRod = new BooleanSetting("Fish_Rod",false);

    private final NumberSetting backdelay = new NumberSetting("BackDelay",20.0,1000.0,0.0,1);

    private final TimerUtil timer = new TimerUtil();

    private final TimerUtil timer2 = new TimerUtil();


    public static final List<EntityPlayer> targets = new ArrayList<>();


    public static EntityPlayer target;


    public static int tick = 0;

    public static boolean isthrowout = false;


    @Override
    public void onMotionEvent(MotionEvent event){

        targets.sort(Comparator.comparingDouble(mc.thePlayer::getDistanceToEntity));
        if (!targets.isEmpty()) {
            target = targets.get(0);
        } else {
            this.setSuffix("None");
            target = null;
        }

            for (Entity entity : mc.theWorld.getLoadedEntityList()) {
                if (entity instanceof EntityFishHook) {
                    if (isthrowout) {
                        if ((((EntityFishHook) entity).caughtEntity != null && ((EntityFishHook) entity).caughtEntity == target) || entity.onGround) {
                            isthrowout = false;
                            mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));
                        }
                    }
                }
            }
            if (isthrowout) {
                this.setSuffix("FishRod");
                if (timer2.hasTimeElapsed(backdelay.getValue()) || KillAura.target != null || Tenacity.INSTANCE.getModuleCollection().getModule(Scaffold.class).isEnabled()) {
                        isthrowout = false;
                        mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));
                }
            }

        if(isthrowout || (findBall() == -1 && (findfishRod() == -1 || !fishRod.isEnabled())) || !timer.hasTimeElapsed(delay.getValue()) || KillAura.target != null || Tenacity.INSTANCE.getModuleCollection().getModule(Scaffold.class).isEnabled()) return;

        for (Entity entity : mc.theWorld.getLoadedEntityList()) {
            if (entity instanceof EntityPlayer) {
                if (mc.thePlayer.getDistanceToEntity(entity) <= range.getValue() && mc.thePlayer != entity && !Teams.check((EntityLivingBase) entity)) {
                    targets.add((EntityPlayer) entity);
                }
            }
        }

        float[] rotation = RotationUtils.getThrowRotation(target,range.getValue().floatValue());

        if(target != null && mc.thePlayer.getDistanceToEntity(target) <= range.getValue() && RotationUtils.getRotationDifference(target) <= fov.getValue() && mc.thePlayer.canEntityBeSeen(target)){
            tick += 1;
            RotationComponent.setRotations(rotation,10, MovementFix.NORMAL);
            if(tick > 3) {
                if(findBall() != -1) {
                    this.setSuffix("SnowBall");
                    mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(findBall() - 36));
                    mc.getNetHandler().addToSendQueue(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getStackInSlot(findBall() - 36)));
                    mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(mc.thePlayer.inventory.currentItem));
                }else{
                    if(findfishRod() != -1 && !isthrowout && fishRod.isEnabled()){
                        mc.getNetHandler().addToSendQueue(new C09PacketHeldItemChange(findfishRod() - 36));
                        mc.getNetHandler().addToSendQueue(new C08PacketPlayerBlockPlacement(mc.thePlayer.inventory.getStackInSlot(findfishRod() - 36)));
                        isthrowout = true;
                        timer2.reset();
                    }
                }
                target = null;
                targets.clear();
                timer.reset();
                tick = 0;
            }
        }else{
            tick = 0;
        }
    }
    public static int findfishRod() {
        for (int i = 36; i < 45; ++i) {
            final ItemStack itemStack = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
            if (itemStack != null && (itemStack.getItem().equals(Items.fishing_rod))){
                return i;
            }
        }
        return -1;
    }
    public static int findBall() {
        for (int i = 36; i < 45; ++i) {
            final ItemStack itemStack = mc.thePlayer.inventoryContainer.getSlot(i).getStack();
            if (itemStack != null && (itemStack.getItem().equals(Items.snowball) || itemStack.getItem().equals(Items.egg)) && itemStack.stackSize > 0) {
                return i;
            }
        }
        return -1;
    }
    public ThrowerAura() {
        super("ThrowerAura", Category.COMBAT, "QWQ");
        addSettings(range,delay,fov,fishRod,backdelay);
    }
}
