package dev.tenacity.module.impl.misc;

import dev.tenacity.commands.impl.FriendCommand;
import dev.tenacity.event.impl.player.UpdateEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.module.settings.ParentAttribute;
import dev.tenacity.module.settings.Setting;
import dev.tenacity.module.settings.impl.BooleanSetting;
import dev.tenacity.module.settings.impl.MultipleBoolSetting;
import dev.tenacity.utils.player.PlayerUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;
import net.minecraft.scoreboard.ScorePlayerTeam;
import net.minecraft.util.StringUtils;

import java.util.ArrayList;

public class Teams extends Module {
    private static MultipleBoolSetting modeValue = new MultipleBoolSetting("Check Mode", "LiquidBounce", "Other", "ChatGPT");
    private static BooleanSetting scoreboardValue = new BooleanSetting("ScoreboardTeam", false);
    private static BooleanSetting colorValue = new BooleanSetting("Color", true);
    private  static BooleanSetting gommeSWValue = new BooleanSetting("GommeSW", false);
    private static BooleanSetting armorColorValue = new BooleanSetting("ArmorColor", false);
    private static BooleanSetting caoNiMa = new BooleanSetting("SameTeams", true);

    public Teams() {
        super("Teams" ,Category.MISC,"Teams");
        ArrayList<Setting> settings = new ArrayList<>();
        settings.add(modeValue);
        settings.add(scoreboardValue);
        settings.add(colorValue);
        settings.add(gommeSWValue);
        settings.add(armorColorValue);
        settings.add(caoNiMa);
        addSettings(settings);
        caoNiMa.addParent(modeValue.getSetting("LiquidBounce"), ParentAttribute.BOOLEAN_CONDITION);
        gommeSWValue.addParent(modeValue.getSetting("LiquidBounce"), ParentAttribute.BOOLEAN_CONDITION);
    }
    private void addSettings(ArrayList<Setting> settings) {

    }
    private static Teams teams;

    public static boolean check(EntityLivingBase entity) {
        return teams != null && teams.isEnabled() && isInYourTeam(entity);
    }

    public void onUpdateEvent() {
        teams = this;
    }

    /**
     * Check if [entity] is in your own team using scoreboard, name color or team prefix
     */
    public static boolean isInYourTeam(EntityLivingBase entity) {
        Minecraft mc = Minecraft.getMinecraft();
        EntityPlayer thePlayer = mc.thePlayer;
        if (thePlayer == null) {
            return false;
        }

        if (entity instanceof EntityPlayer && modeValue.isEnabled("Other")) {
            return (
                    (armorColorValue.isEnabled() && PlayerUtil.armorTeam((EntityPlayer) entity)) ||
                            (colorValue.isEnabled() && PlayerUtil.colorTeam((EntityPlayer) entity)) ||
                            (scoreboardValue.isEnabled() && PlayerUtil.scoreTeam((EntityPlayer) entity))
            );
        }

        if (modeValue.isEnabled("ChatGPT")) {
            ScorePlayerTeam thePlayerTeam = (ScorePlayerTeam) mc.thePlayer.getTeam();
            ScorePlayerTeam entityTeam = (ScorePlayerTeam) entity.getTeam();
            if (thePlayerTeam == null || entityTeam == null) {
                return false;
            }
            return thePlayerTeam.getColorPrefix().equals(entityTeam.getColorPrefix());
        }

        if (modeValue.isEnabled("LiquidBounce")) {
            if (caoNiMa.isEnabled()) {
                return thePlayer.isOnSameTeam(entity);
            }

            if (scoreboardValue.isEnabled() && mc.thePlayer.getTeam()!= null && entity.getTeam()!= null &&
                    mc.thePlayer.getTeam().isSameTeam(entity.getTeam())) {
                EntityPlayer player = (EntityPlayer) entity;
                String name = StringUtils.stripControlCodes(player.getName());
                FriendCommand.friends.add(name);
                return true;
            }

            if (gommeSWValue.isEnabled() && mc.thePlayer.getDisplayName()!= null && entity.getDisplayName()!= null) {
                String targetName = entity.getDisplayName().getFormattedText().replace("§r", "");
                String clientName = mc.thePlayer.getDisplayName().getFormattedText().replace("§r", "");
                if (targetName.startsWith("T") && clientName.startsWith("T")) {
                    if (targetName.charAt(1) >= '0' && targetName.charAt(1) <= '9' && clientName.charAt(1) >= '0' && clientName.charAt(1) <= '9' && targetName.charAt(1) == clientName.charAt(1)) {
                        EntityPlayer player = (EntityPlayer) entity;
                        String name = StringUtils.stripControlCodes(player.getName());
                        FriendCommand.friends.add(name);
                        return true;
                    }
                }
            }

            if (armorColorValue.isEnabled()) {
                EntityPlayer entityPlayer = (EntityPlayer) entity;
                if (mc.thePlayer.inventory.armorInventory[3]!= null && entityPlayer.inventory.armorInventory[3]!= null) {
                    Object myHead = mc.thePlayer.inventory.armorInventory[3];
                    Object myItemArmor = mc.thePlayer.inventory.armorInventory[3].getItem();
                    Object entityHead = entityPlayer.inventory.armorInventory[3];
                    Object entityItemArmor = (mc.thePlayer.inventory.armorInventory[3].getItem());
                    ItemArmor entityItemArmor1 = (ItemArmor) entityItemArmor;
                    ItemArmor myItemArmor1 = (ItemArmor) myItemArmor;
                    if (myItemArmor1.getColor((ItemStack) myHead) == entityItemArmor1.getColor((ItemStack) entityHead)) {
                        EntityPlayer player = (EntityPlayer) entity;
                        String name = StringUtils.stripControlCodes(player.getName());
                        FriendCommand.friends.add(name);
                        return true;
                    }
                }
            }

            if (colorValue.isEnabled() && mc.thePlayer.getDisplayName()!= null && entity.getDisplayName()!= null) {
                String targetName = entity.getDisplayName().getFormattedText().replace("§r", "");
                String clientName = mc.thePlayer.getDisplayName().getFormattedText().replace("§r", "");
                if (targetName.startsWith("§" + clientName.charAt(1))) {
                    EntityPlayer player = (EntityPlayer) entity;
                    String name = StringUtils.stripControlCodes(player.getName());
                    FriendCommand.friends.add(name);
                    return true;
                }
            }

            return false;
        }
        return false;
    }


}