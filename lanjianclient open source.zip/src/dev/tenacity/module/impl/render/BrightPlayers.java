package dev.tenacity.module.impl.render;

import dev.tenacity.module.Category;
import dev.tenacity.module.Module;

public class BrightPlayers extends Module {

    public BrightPlayers(){
        super("BrightPlayers", Category.RENDER, "Makes players bright");
    }


}
