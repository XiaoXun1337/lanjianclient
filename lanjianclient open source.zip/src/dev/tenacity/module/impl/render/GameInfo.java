package dev.tenacity.module.impl.render;

import dev.tenacity.Tenacity;
import dev.tenacity.event.impl.player.UpdateEvent;
import dev.tenacity.event.impl.render.Render2DEvent;
import dev.tenacity.event.impl.render.ShaderEvent;
import dev.tenacity.module.Category;
import dev.tenacity.module.Module;
import dev.tenacity.utils.font.FontUtil;
import dev.tenacity.utils.objects.Dragging;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.render.RoundedUtil;
import dev.tenacity.utils.render.StencilUtil;

import java.awt.*;

import static dev.tenacity.module.impl.render.HUDMod.radius;
import static dev.tenacity.utils.font.FontUtil.tenacityFont16;

public class GameInfo extends Module {
    private final Dragging GameInfo_dragging = Tenacity.INSTANCE.createDrag(this, "SessionInfo", 8, 30);
    float gameinfo_width = 145;
    float gameinfo_height = 60;
    public static long startTime = System.currentTimeMillis(), endTime = -1;
    public GameInfo() {
        super("SessionInfo", Category.RENDER, "SessionInfo");
        if (!enabled) this.toggleSilent();
    }

    @Override
    public void onUpdateEvent(UpdateEvent event) {
        if (mc.thePlayer.isDead) {
            ++ deathcoun;
        }
    }

    @Override
    public void onShaderEvent(ShaderEvent event) {
        GameInfo_dragging.setWidth(gameinfo_width);
        GameInfo_dragging.setHeight(gameinfo_height);
        float alpha = 1f;
        HUDMod.colorWheel.setColors();
        RoundedUtil.drawThemeColorRound(GameInfo_dragging.getX(), GameInfo_dragging.getY(),
                GameInfo_dragging.getWidth(), GameInfo_dragging.getHeight(), radius.getValue().floatValue(),
                ColorUtil.applyOpacity(HUDMod.colorWheel.getColor1(), alpha),
                ColorUtil.applyOpacity(HUDMod.colorWheel.getColor4(), alpha),
                ColorUtil.applyOpacity(HUDMod.colorWheel.getColor2(), alpha),
                ColorUtil.applyOpacity(HUDMod.colorWheel.getColor3(), alpha),new Color(30,30,30));
    }

    @Override
    public void onRender2DEvent(Render2DEvent event) {
        GameInfo_dragging.setWidth(gameinfo_width);
        GameInfo_dragging.setHeight(gameinfo_height);
        HUDMod.colorWheel.setColors();
        float alpha = .17f;
        RoundedUtil.drawThemeColorRound(GameInfo_dragging.getX(), GameInfo_dragging.getY(), GameInfo_dragging.getWidth(),
                gameinfo_height, radius.getValue().floatValue(),ColorUtil.applyOpacity(HUDMod.colorWheel.getColor1(), alpha),
                ColorUtil.applyOpacity(HUDMod.colorWheel.getColor4(), alpha),
                ColorUtil.applyOpacity(HUDMod.colorWheel.getColor2(), alpha),
                ColorUtil.applyOpacity(HUDMod.colorWheel.getColor3(), alpha),new Color(0,0,0,60));

        RoundedUtil.drawRound(GameInfo_dragging.getX(), GameInfo_dragging.getY() + 4, 1.5f,
                tenacityBoldFont22.getHeight()-3, HUDMod.barRadius.getValue().floatValue(),
                ColorUtil.applyOpacity(HUDMod.colorWheel.getColor1(), 1));
//
        StencilUtil.initStencilToWrite();
        RoundedUtil.drawRound(GameInfo_dragging.getX() + 6, GameInfo_dragging.getY() + 15, 40, 40, 8,
                ColorUtil.applyOpacity(HUDMod.colorWheel.getColor1(), 1));
        StencilUtil.bindReadStencilBuffer(1);
        RenderUtil.resetColor();
        RenderUtil.setAlphaLimit(0);
        RenderUtil.resetColor();
        RenderUtil.drawHead(mc.thePlayer.getLocationSkin(), GameInfo_dragging.getX() + 6, GameInfo_dragging.getY() + 15, 40, 40,  255);
        StencilUtil.uninitStencilBuffer();
//

        FontUtil.tenacityBoldFont20.drawString("SessionInfo", GameInfo_dragging.getX() + 5, GameInfo_dragging.getY() +3,
                new Color(255,255,255,200));

        FontUtil.tenacityBoldFont18.drawString("User: ", GameInfo_dragging.getX() + 50, GameInfo_dragging.getY() + 20,
                new Color(255,255,255,180));
        tenacityFont16.drawString(" "+mc.thePlayer.getName(), GameInfo_dragging.getX() + 69, GameInfo_dragging.getY() + 22,
                new Color(255,255,255,160));

        FontUtil.tenacityBoldFont16.drawString("K/D: ", GameInfo_dragging.getX() + 50, GameInfo_dragging.getY() + 32.5f,
                new Color(255,255,255,180));

        FontUtil.tenacityBoldFont16.drawString(" " + killcoun + "/" + deathcoun,
                GameInfo_dragging.getX() + 65.5f, GameInfo_dragging.getY() + 32.5f, new Color(255,255,255,160));

        FontUtil.tenacityBoldFont18.drawString("Playtime: ",
                GameInfo_dragging.getX() + 50, GameInfo_dragging.getY() + 44,
                new Color(255,255,255,180));
        FontUtil.tenacityBoldFont16.drawString(" "+getPlayTime()[0] + "h " + getPlayTime()[1] + "m " + getPlayTime()[2] + "s",
                GameInfo_dragging.getX() + 87, GameInfo_dragging.getY() + 45, new Color(255,255,255,160));
    }
    public static int[] getPlayTime() {
        long diff = getTimeDiff();
        long diffSeconds = 0, diffMinutes = 0, diffHours = 0;
        if (diff > 0) {
            diffSeconds = diff / 1000 % 60;
            diffMinutes = diff / (60 * 1000) % 60;
            diffHours = diff / (60 * 60 * 1000) % 24;
        }
        return new int[]{(int) diffHours, (int) diffMinutes, (int) diffSeconds};
    }
    public static long getTimeDiff() {
        return (endTime == -1 ? System.currentTimeMillis() : endTime) - startTime;
    }

    public static void reset() {
        startTime = System.currentTimeMillis();
        endTime = -1;
    }
    public static int deathcoun = 0;
    public static int killcoun = 0;

}