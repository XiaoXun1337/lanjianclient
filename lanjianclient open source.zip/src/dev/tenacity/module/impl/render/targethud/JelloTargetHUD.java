/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package dev.tenacity.module.impl.render.targethud;

import dev.tenacity.module.impl.render.TargetHUDMod;
import dev.tenacity.utils.animations.ContinualAnimation;
import dev.tenacity.utils.font.FontUtil;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.render.RoundedUtil;
import dev.tenacity.utils.render.StencilUtil;
import java.awt.Color;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;

import static dev.tenacity.utils.font.FontUtil.*;

public class JelloTargetHUD
extends TargetHUD {
    private final ContinualAnimation animation = new ContinualAnimation();

    public JelloTargetHUD() {
        super("Jello");
    }

    @Override
    public void render(float x, float y, float alpha, EntityLivingBase target) {
        this.setWidth(Math.max(150.0f, tenacityFont26.getStringWidth(target.getName()) + 45.0f));
        this.setHeight(42.0f);
        Color c1 = ColorUtil.applyOpacity(new Color(255, 255, 255), alpha);
        Color c2 = ColorUtil.applyOpacity(new Color(215, 215, 215), alpha);
        Color color = new Color(255, 255, 255, (int)(25.0f * alpha));
        int textColor = ColorUtil.applyOpacity(-1, alpha);
        RoundedUtil.drawRound(x, y, this.getWidth(), this.getHeight(), 4.0f, color);
        if (target instanceof AbstractClientPlayer) {
            StencilUtil.initStencilToWrite();
            RenderUtil.renderRoundedRect(x + 3.0f, y + 3.0f, 36.0f, 36.0f, 4.0f, -1);
            StencilUtil.readStencilBuffer(1);
            RenderUtil.color(-1, alpha);
            this.renderPlayer2D(x + 3.0f, y + 3.0f, 36.0f, 36.0f, (AbstractClientPlayer)target);
            StencilUtil.uninitStencilBuffer();
            GlStateManager.disableBlend();
        } else {
            tenacityFont32.drawStringWithShadow("?", x + 20.0f, y + 17.0f - (float)tenacityFont32.getHeight() / 2.0f, textColor);
        }
        tenacityFont26.drawStringWithShadow(target.getName(), x + 43.5f, y + 4.0f, textColor);
        tenacityFont24.drawStringWithShadow(target.getHealth() >= JelloTargetHUD.mc.thePlayer.getHealth() ? "Losing" : "Winning", x + 44.0f, y + 18.0f, textColor);
        float healthPercent = MathHelper.clamp_float((target.getHealth() + target.getAbsorptionAmount()) / (target.getMaxHealth() + target.getAbsorptionAmount()), 0.0f, 1.0f);
        float realHealthWidth = this.getWidth() - 48.0f;
        float realHealthHeight = 3.0f;
        this.animation.animate(realHealthWidth * healthPercent, 18);
        Color backgroundHealthColor = new Color(0, 0, 0, (int)alpha * 110);
        float healthWidth = this.animation.getOutput();
        RoundedUtil.drawRound(x + 44.0f, y + this.getHeight() - 8.0f, 98.0f, realHealthHeight, 1.5f, backgroundHealthColor);
        RoundedUtil.drawGradientHorizontal(x + 44.0f, y + this.getHeight() - 8.0f, healthWidth, realHealthHeight, 1.5f, c1, c2);
    }


    @Override
    public void renderEffects(float x, float y, float alpha, boolean glow) {
        RoundedUtil.drawRound(x, y, this.getWidth(), this.getHeight(), 4.0f, ColorUtil.applyOpacity(Color.BLACK, alpha));
    }
}

