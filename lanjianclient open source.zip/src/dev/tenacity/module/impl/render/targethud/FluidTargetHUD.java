package dev.tenacity.module.impl.render.targethud;

import dev.tenacity.module.impl.render.HUDMod;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.render.RoundedUtil;
import java.awt.Color;
import java.text.DecimalFormat;

import dev.tenacity.utils.render.StencilUtil;
import dev.tenacity.utils.font.ChineseFontRenderer;
import dev.tenacity.utils.font.FontUtil;
import dev.tenacity.utils.font.CustomFont;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityLivingBase;

import static dev.tenacity.utils.font.FontUtil.*;

public class FluidTargetHUD extends TargetHUD {
    public FluidTargetHUD() {
        super("Fluid");
    }

    public void render(float x, float y, float alpha, EntityLivingBase target) {
        float width;
        float height;
            width = Math.max(120.0F, tenacityBoldFont18.getStringWidth(target.getName()) + 50.0F);
            height = 35.0F;
            this.setWidth(width);
            this.setHeight(height);
            RoundedUtil.drawRound(x, y, width, height, 2.0F, new Color(0, 0, 0, 100));
        int textColor = ColorUtil.applyOpacity(-1, alpha);
        if (target instanceof AbstractClientPlayer) {
            StencilUtil.initStencilToWrite();
            RenderUtil.renderRoundedRect(x + 2, y + 2, 29, 31, 2, -1);
            StencilUtil.readStencilBuffer(1);
            RenderUtil.color(-1, alpha);
            renderPlayer2D(x + 2, y + 2, 29, 31, (AbstractClientPlayer) target);
            StencilUtil.uninitStencilBuffer();
            GlStateManager.disableBlend();
        } else {
            tenacityFont32.drawStringWithShadow("?", x + 13, y + 12 - tenacityFont16.getHeight() / 2f, textColor);
        }
            tenacityFont16.drawStringWithShadow(target.getName(), x + 36.0F, y + 5.0F, new Color(((Color) HUDMod.colorWheel.getColor1()).getRGB()));
            RoundedUtil.drawRound(x + 36.0F, y + 10.0F + (float) tenacityFont16.getHeight(), width - 40.0F, 5.0F, 2.0F, new Color(0, 0, 0, 30));
            //绘制血条
            RoundedUtil.drawGradientHorizontal(x + 36.0F, y + 5.0F + (float) tenacityFont16.getHeight(), target.getHealth() / target.getMaxHealth() * (width - 40.0F), 8.0F, 2.0F, (Color) HUDMod.colorWheel.getColor1(), (Color) HUDMod.colorWheel.getColor2());
            tenacityBoldFont14.drawString((new DecimalFormat("0.00")).format((double) target.getHealth()) + " HP", x + 36.0F, y + height - 8.0F, new Color(-1));
        }

    /**
     * @param x
     * @param y
     * @param alpha
     */
    @Override
    public void renderEffects(float x, float y, float alpha, boolean glow) {
                RoundedUtil.drawRound(x, y, this.getWidth(), this.getHeight(), 2.0F, ColorUtil.applyOpacity(Color.BLACK, alpha));
            }
        }
