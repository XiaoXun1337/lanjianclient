/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package dev.tenacity.module.impl.render.targethud;

import dev.tenacity.module.impl.render.HUDMod;
import dev.tenacity.module.impl.render.Streamer;
import dev.tenacity.module.impl.render.TargetHUDMod;
import dev.tenacity.utils.animations.ContinualAnimation;
import dev.tenacity.utils.font.FontUtil;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RoundedUtil;
import dev.tenacity.utils.render.StencilUtil;
import java.awt.Color;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.Gui;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;

import static dev.tenacity.utils.font.FontUtil.*;

public class EchoTargetHUD
        extends TargetHUD {
    private final ContinualAnimation animatedHealthBar = new ContinualAnimation();

    public EchoTargetHUD() {
        super("Echo");
    }

    @Override
    public void render(float x, float y, float alpha, EntityLivingBase target) {
        this.setWidth(Math.max(145.0f, tenacityFont24.getStringWidth(target.getName()) + 40.0f));
        this.setHeight(35.0f);
        Color firstColor = ColorUtil.applyOpacity(HUDMod.getClientColors().getFirst(), alpha);
        Color secondColor = ColorUtil.applyOpacity(HUDMod.getClientColors().getSecond(), alpha);
        Color color = ColorUtil.applyOpacity(Color.BLACK, 0.3f);
        int textColor = ColorUtil.applyOpacity(-1, alpha);
        Gui.drawRect2(x, y, this.getWidth(), this.getHeight(), color.getRGB());
//        Gui.drawRect2(x, y, this.getWidth(), 15.0, color.getRGB());
//        tenacityFont20cfr.drawStringWithShadow("Target", x + this.getWidth() / 2.0f - tenacityFont20cfr.getStringWidth("Target") / 1.2f, y + tenacityFont20cfr.getMiddleOfBox(15.0f), textColor);
//        tenacityFont20cBfr.drawStringWithShadow("Info", x + this.getWidth() / 2.0f + tenacityFont20cBfr.getStringWidth("Info") / 2.2f, y + tenacityFont20cBfr.getMiddleOfBox(15.0f), textColor);
        if (target instanceof AbstractClientPlayer) {
            this.renderPlayer2D(x, y, 35.0f, 35.0f, (AbstractClientPlayer)target);
        } else {
            Gui.drawRect2(x, y + 15.0f, 35.0, 35.0, ColorUtil.applyOpacity(Color.WHITE.getRGB(), 0.5f));
            tenacityFont32.drawStringWithShadow("?", x + 20.5f - tenacityFont32.getStringWidth("?") / 2.0f, y + 17.5f - (float)tenacityFont32.getHeight() / 2.0f, textColor);
        }
        tenacityFont24.drawStringWithShadow(Streamer.enabled ? Streamer.customName.getString() : target.getName(), x + 40.0f, y + 5.5f, textColor);
        float healthPercent = MathHelper.clamp_float((target.getHealth() + target.getAbsorptionAmount()) / (target.getMaxHealth() + target.getAbsorptionAmount()), 0.0f, 1.0f);
        float realHealthWidth = this.getWidth() - 45.0f;
        float realHealthHeight = 5.0f;
        this.animatedHealthBar.animate(realHealthWidth * healthPercent, 50);
        float healthWidth = this.animatedHealthBar.getOutput();
        RoundedUtil.drawRound(x + 40.0f, y + this.getHeight() - 10.0f, realHealthWidth, realHealthHeight, 1.0f, color);
        RoundedUtil.drawGradientHorizontal(x + 40.0f, y + this.getHeight() - 10.0f, healthWidth, realHealthHeight, 1.0f, firstColor, secondColor);
        StencilUtil.uninitStencilBuffer();
    }


    @Override
    public void renderEffects(float x, float y, float alpha, boolean glow) {
        RoundedUtil.drawRound(x + 0.75f, y + 0.75f, this.getWidth() - 1.5f, this.getHeight() - 1.5f, 4.0f, Color.BLACK);
    }
}

