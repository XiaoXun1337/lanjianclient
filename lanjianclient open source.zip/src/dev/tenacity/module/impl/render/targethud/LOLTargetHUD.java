package dev.tenacity.module.impl.render.targethud;

import dev.tenacity.module.impl.render.HUDMod;
import dev.tenacity.utils.animations.ContinualAnimation;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.RenderUtil;
import dev.tenacity.utils.render.RoundedUtil;
import dev.tenacity.utils.render.StencilUtil;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;
import net.minecraft.util.ResourceLocation;

import java.awt.*;

public class LOLTargetHUD extends TargetHUD {

    private final ContinualAnimation animation = new ContinualAnimation();

    public LOLTargetHUD() {
        super("LOL");
    }

    @Override
    public void render(float x, float y, float alpha, EntityLivingBase target) {
        setWidth(95);
        setHeight(35);
        float healthPercent = MathHelper.clamp_float((target.getHealth() + target.getAbsorptionAmount()) / (target.getMaxHealth() + target.getAbsorptionAmount()), 0, 1);

        float realHealthWidth = getWidth() - 1;
        animation.animate(realHealthWidth * healthPercent, 18);

        float healthWidth = animation.getOutput();

        StencilUtil.initStencilToWrite();
        RoundedUtil.drawRound(x, y - 55, getWidth(), getWidth(), 4, ColorUtil.applyOpacity(Color.WHITE, alpha));
        StencilUtil.readStencilBuffer(1);
        RenderUtil.color(-1, alpha);
        RenderUtil.drawImage(new ResourceLocation("Tenacity/LOLdiv.png"), x, y, getWidth(), getHeight());
        StencilUtil.uninitStencilBuffer();
        GlStateManager.disableBlend();


        RoundedUtil.drawRound(x, y, healthWidth, getHeight(), 2, new Color(0, 0, 0, 80));
        String health = String.valueOf((int) target.getHealth());
        tenacityBoldFont28.drawSmoothStringWithShadow(health, x + 76, y + 5, new Color(211, 104, 100).getRGB());
    }


    @Override
    public void renderEffects(float x, float y, float alpha, boolean glow) {
//        RoundedUtil.drawRound(x, y, getWidth(), getHeight(), 2, ColorUtil.applyOpacity(Color.BLACK, alpha));
        RoundedUtil.drawGradientHorizontal(x, y, getWidth(), getHeight(), 2, HUDMod.getClientColors().getFirst(), HUDMod.getClientColors().getSecond());
    }
}

