/*
 * Decompiled with CFR 0.153-SNAPSHOT (d6f6758-dirty).
 */
package dev.tenacity.module.impl.render.targethud;

import dev.tenacity.module.impl.render.HUDMod;
import dev.tenacity.module.impl.render.TargetHUDMod;
import dev.tenacity.utils.animations.ContinualAnimation;
import dev.tenacity.utils.font.ChineseFontRenderer;
import dev.tenacity.utils.font.CustomFont;
import dev.tenacity.utils.render.ColorUtil;
import dev.tenacity.utils.render.GLUtil;
import dev.tenacity.utils.render.RenderUtil;
import java.awt.Color;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.gui.Gui;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.MathHelper;




public class ExireTargetHUD
extends TargetHUD {
    private final ContinualAnimation animation = new ContinualAnimation();

    public ExireTargetHUD() {
        super("Exire");
    }

    @Override
    public void render(float x, float y, float alpha, EntityLivingBase target) {
        CustomFont fr = tenacityFont26;
        this.setWidth(fr.getStringWidth(target.getName()) + 27.0f);
        this.setHeight(30.0f);
        double healthPercentage = MathHelper.clamp_float((target.getHealth() + target.getAbsorptionAmount()) / (target.getMaxHealth() + target.getAbsorptionAmount()), 0.0f, 1.0f);
        Color c1 = ColorUtil.applyOpacity(HUDMod.getClientColors().getFirst(), alpha);
        Color c2 = ColorUtil.applyOpacity(HUDMod.getClientColors().getSecond(), alpha);
        float width = fr.getStringWidth(target.getName()) + 27.0f;
        float endWidth = (float)Math.max(0.0, (double)(width - 34.0f) * healthPercentage);
        this.animation.animate(endWidth, 15);
        float healthWidth = this.animation.getOutput();
        int alphaInt = (int)(alpha * 255.0f);
        Gui.drawRect2(x + 1.0f, y + 1.0f, this.getWidth() - 2.0f + 3.0f + 2.0f, this.getHeight() - 2.0f - 2.0f, new Color(40, 40, 40, alphaInt).getRGB());
        RenderUtil.drawGradientRect(x + 25.5f + 3.0f, y + 19.0f, x + width - 4.0f + 2.0f + 1.0f + 2.0f, y + 25.0f, new Color(0, 0, 0, 150).getRGB(), new Color(0, 0, 0, 150).getRGB());
        RenderUtil.drawGradientRect(x + 25.5f + 3.0f, y + 19.0f, x + 30.0f + healthWidth + 2.0f + 1.0f + 2.0f, y + 25.0f, c1.darker().darker().getRGB(), c2.darker().darker().getRGB());
        RenderUtil.drawGradientRect(x + 25.5f + 3.0f, y + 19.0f, x + 30.0f + Math.min(endWidth, healthWidth) + 2.0f + 2.0f, y + 25.0f, c1.getRGB(), c2.getRGB());
        int textColor = ColorUtil.applyOpacity(-1, alpha);
        int mcTextColor = ColorUtil.applyOpacity(-1, (float)Math.max(0.1, (double)alpha));
        GLUtil.startBlend();
        if (target instanceof AbstractClientPlayer) {
            RenderUtil.color(textColor);
            this.renderPlayer2D(x + 3.5f, y + 3.0f, 22.0f, 22.0f, (AbstractClientPlayer)target);
        }
        GLUtil.startBlend();
        fr.drawStringWithShadow(target.getName(), x + 25.5f + 3.0f, y + 4.0f, mcTextColor);
    }

    @Override
    public void renderEffects(float x, float y, float alpha, boolean glow) {
        Gui.drawRect2(x, y, this.getWidth(), this.getHeight(), ColorUtil.applyOpacity(Color.BLACK.getRGB(), alpha));
    }
}

