package dev.tenacity.module.impl.render;

import dev.tenacity.module.Category;
import dev.tenacity.module.Module;

public class MotionGraph extends Module {


    public MotionGraph() {
        super("MotionGraph", Category.RENDER, "Shows a graph of your motion");
    }

}
