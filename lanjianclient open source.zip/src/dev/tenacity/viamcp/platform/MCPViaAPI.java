package dev.tenacity.viamcp.platform;

import com.viaversion.viaversion.ViaAPIBase;

import java.util.UUID;

public class MCPViaAPI extends ViaAPIBase<UUID> {
}
